import os                    #File: scheduler.py   
import sys 			         #Author: Giovanni Bettinazzi
import MySQLdb				 #email: g.bettinazzi@gmail.com
import json
import os
import csv

class Database:
	def __init__(self, host='127.0.0.1', user='root', pwd='csabamonory', db='EA-SIMDB'): #portatile host =127.0.0.1, fisso = localhost , gozzo = 10.79.3.212 pwd = easimpassword
		self.host = host
		self.user = user
		self.pwd = pwd
		self.db = db
		self.cur = None

	def open(self):
		self.con = MySQLdb.connect(
		host = self.host,
		user = self.user,
		passwd = self.pwd,
		db = self.db
		)

		self.cur = self.con.cursor()


	def close(self):
		return self.con.close()

# for record in executeReadQuery(query): ...
	def executeReadQuery(self, query):
		self.cur.execute(query)
		return self.cur.fetchall()

	def executeFormatReadQuery(self, query,formato):
		self.cur.execute(query,formato)
		return self.cur.fetchall()

	def executeFormatWriteQuery(self, query,formato):
		self.cur.execute(query,formato)
		self.con.commit()

	def executeWriteQuery(self, query):
		self.cur.execute(query)
		self.con.commit()

	def getLastInsertedId(self):
		return self.cur.lastrowid


def read_json(string):
  with open(string,'r') as json_file:
      data = json.load(json_file,encoding='ascii') 
      json_file.close()
  return data

def read_csv(file_name):
	result =""
	with open(file_name, 'rb') as csvfile: 								
		spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
		for row in spamreader:
			result = result+'\n'+str(row)
	return result
#---------------------------CREATE THE PREDICTED GANTT --------------------------------

# #Call the script that generate the predicted gantt for a user profile and a specific day
# os.chdir(os.path.abspath("Learning"))   #Set Learning as working directory  
# os.system("python create_predicted_gantt.py") 

#---------------------------CREATE ALL THE COMBINATION OF GANTT --------------------------------

#TO RUN create_tmp_gantt for the first time
tmp_gantt_path =os.path.abspath(os.path.join(os.getcwd(), os.pardir))+"/Sistema_Completo/Tmp_Gantt" 
os.chdir(os.path.abspath(tmp_gantt_path))   #Set Tmp_gantt as working directory  
os.system("python create_tmp_gantt.py 15")  #Run the script and create all the tmp gantt


#---------------------------Read each gantt_content in the db --------------------------------
os.chdir(os.path.abspath(os.path.join(os.getcwd(), os.pardir)))
sqlR="SELECT `Gantt_content` FROM `Gantt` WHERE `Gantt_name`= (%s)"   #the read query body
name_gantt = "gantt.json"
formato = "(name,content)"     #the content of the %s place holders
sqlW_not_fulfill= "INSERT INTO `Results_not_fulfill`(`Gantt_name`,`Gantt_content`,`Consumption`) VALUES (%s,%s,%s)"    #the write query body
sqlW_fulfill= "INSERT INTO `Results_fulfill`(`Gantt_name`,`Gantt_content`,`Consumption`) VALUES (%s,%s,%s)"    #the write query body
sqlW_24= "INSERT INTO `All_Results_24`(`Gantt_name`,`Gantt_content`,`Consumption`) VALUES (%s,%s,%s)"    #the write query body
sqlJoin="CREATE TABLE Results_fulfill_24 SELECT All_Results_24.Gantt_name, All_Results_24.Gantt_content, All_Results_24.Consumption FROM All_Results_24 JOIN Results_fulfill ON All_Results_24.Gantt_name = Results_fulfill.Gantt_name "
db=Database()
db.open()
f = open("./Tmp_Gantt/list.txt")   #list of gantt file presents in the db
lines = f.readlines()
f.close()
os.chdir(os.path.abspath("EA-SIM2.0"))  #Changing the working directory to the EA-SIM2.0 directory
db.executeWriteQuery('DELETE FROM `Results_not_fulfill` WHERE 1')  #delete the Results_not_fulfill table before write
db.executeWriteQuery('DELETE FROM `Results_fulfill` WHERE 1')  #delete the Results_fulfill table before write
db.executeWriteQuery('DELETE FROM `All_Results_24` WHERE 1')  #delete the Results_fulfill table before write
db.executeWriteQuery('DROP TABLE `Results_fulfill_24`')
for line in lines:
	name=line.replace(".json","")[:-1]   #the name of the gantt file
	t = str(db.executeFormatReadQuery(sqlR,(name,))).replace("(","").replace("'","")[:-4]  #at each iteration get a new gantt from the Gantt table in the DB 
	f = open("gantt.json",'w+')  #overwrite the previous gantt file
	f.write(t)
	f.close()
	os.system("python easim2.0.py 08:00 09:00 2.5 -s") #Run a simulation
	content = str(read_json(name_gantt)).replace("u'","\"").replace("'","\"")   #the content of the gantt file
	consumption = str(read_csv("./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.csv")) #read the power consumption csv
	formato = "(name,content,consumption)"     #the content of the %s place holders
	fullfill=read_csv("./Data_and_curves/Last_Simulation_Results/System/Aggregator_fullfilment.csv") 
	if("1" in fullfill):  #Save the simulation in the results if the request of the aggregator is fullfilled from the simulation
		db.executeFormatWriteQuery(sqlW_fulfill,(name,content,consumption))   #write the gantt in the db
	else:
		db.executeFormatWriteQuery(sqlW_not_fulfill,(name,content,consumption))   #write the gantt in the db

	print "EA-SIM << Run simulation FOR 24 HOURS"
	os.system("python easim2.0.py 00:00 24:00 2.5 -s") #Run a simulation
	consumption_24 = str(read_csv("./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.csv")) #read the power consumption csv
	db.executeFormatWriteQuery(sqlW_24,(name,content,consumption_24))   #write the gantt in the db
	
db.executeWriteQuery(sqlJoin)	
db.close()

