import json           #File: create_predicted_gantt.py 
import random         #Author: Giovanni Bettinazzi                                       
import csv            #email: g.bettinazzi@gmail.com
import os
import copy
import subprocess

#--------------------------------------------Utility functions -------------------------------------------------------

#Extract a random value from a list of weights
def weighted_choice(weights):
	if(sum(weights) ==0):
		weights= [0.20,0.20,0.20,0.20,0.20]
	rnd = random.random() * sum(weights)
	for i, w in enumerate(weights): #i = index of weight , w = weight[i]
		rnd -= w
		if rnd < 0:
			return i

#Function that modify the probability distribution according to the value picked before, setting 0 the probability of that day (value is an index)
def balance_dist_total(dist,value):
	for i in range(0,5): #number of week day 
		k = dist[i][value]
		dist[i][value]=0
		for j in range(0,len(dist[i])):
			if(dist[i][j] != 0):
				dist[i][j]+=k
#Read a json file 
def read_json(json_path):
  with open(json_path,'r') as json_file:
      data = json.load(json_file) 
      json_file.close()
  return data

#Write a Json file
def write_json(json_path,data):
  with open(json_path,'w') as json_out_file:
        json.dump(data,json_out_file,indent = True,sort_keys=True)
        json_out_file.close()


#--------------------------------------------GET functions -------------------------------------------------------

#Given a weekly and weekend frequency return from 1 up to 3-4 days of the week that can be writed into the log
def get_days(frequency_week,frequency_week_end,name):
	start_index=0
	chosen_indexes =[0]*(frequency_week+frequency_week_end)
	#matrix[i][j] of probability distribution, each row represent the probability to pick the day j if day i has been picked
	dist =[[0,0,0.3,0.3,0.3],[0,0,0,0.5,0.5],[0.5,0,0,0,0.5],[0.5,0.5,0,0,0],[0.3,0.3,0.3,0,0]]
	if frequency_week <5:
		#------------------Pick the first day----------------------------
		start_index= random.randint(0,4)
		chosen_indexes[0]=start_index
		balance_dist_total(dist,start_index)   #balancing probabilities

		#------------- Pick a day for the rest of week , if any --------------
		for i in range(1,frequency_week):
			next = weighted_choice(dist[start_index])
			#next = weighted_choice(dist)
			chosen_indexes[i]=next
			balance_dist_total(dist,next)   #balancing probabilities
			start_index=next
	else:
		for j in range(0,5):
			chosen_indexes[j]=j
	#---------Pick the weekend days, if any----------
	if(frequency_week_end>1):  #pick both randomly
		x = random.randint(0,1)
		chosen_indexes[len(chosen_indexes)-2]=5+x
		chosen_indexes[len(chosen_indexes)-1]=5+(1-x)
	elif(frequency_week_end ==1):  #pick one of them
		x =random.randint(0,1)
		chosen_indexes[len(chosen_indexes)-1]=5+x

	chosen_indexes=sorted(chosen_indexes)  #sort the array before return
	return chosen_indexes

#For a given appliance return a vector time_vect[0:7] where the i-th element will be the activation time for the i-th day
def get_time(dist,indexes):
	time_vect=[""]*7
	for i in range(0,7):   #fill the time_vect array with the activation time for the i-th day, if any
		if i in indexes:
			time_vect[i]+=str(weighted_choice(dist))
	return time_vect


#--------------------------------------------WRITE LOG functions -------------------------------------------------------
def write_vector_csv(vector,csv_path,):
	with open(csv_path,'wb') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		for h in range(0,len(vector)):
			spamwriter.writerow([vector[h]])


def write_week_start(index,file_path):
	with open(file_path,'ab') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		spamwriter.writerow(['Week '+str(index)])
		spamwriter.writerow([' '])

def write_day_on_log(day,file_path):
	with open(file_path,'ab') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		spamwriter.writerow([day])


def write_row_on_log(appliance,time,file_path):
	with open(file_path,'ab') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		spamwriter.writerow([appliance,time])

def write_end_day(file_path):
	with open(file_path,'ab') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		spamwriter.writerow([';'])

def write_end_week(file_path):
	with open(file_path,'ab') as csvfile:
		spamwriter = csv.writer(csvfile, delimiter=' ', quoting=csv.QUOTE_MINIMAL)
		spamwriter.writerow(['###'])



#--------------------------------------------------------LEARNING functions --------------------------------------------------------------------

# --------------------------------------Function for the hours model -------------------------------------------------

#For a specific appliance , update his day->hour score and consider the border effect, so update the score also for the previous and the next hour
def train_hour_vector(appliance,day,hour):
	global hours_score
	if "86400" in data['network'][0]['appliances'][appliance]['Cycle']:  #if the appliance has a continuous behavior in the whole day the hour interval is indifferent for EA-SIM 
		hours_score[appliance][day][23]+=learning_rate_hour
	else:
		for i in range(0,24):
			hours_score[appliance][day][i] *= (1-learning_rate_hour) 
		previousIndex = (hour-1)%24
		nextIndex = (hour+1)%24
		hours_score[appliance][day][hour]+= learning_rate_hour
		hours_score[appliance][day][previousIndex]+= learning_rate_hour * border_effect_rate
		hours_score[appliance][day][nextIndex]+= learning_rate_hour *border_effect_rate

# model is the hours_score vector for a specific day of the week for a specific appliance
# The function return a set of possible hours for the selected appliance to be active on the selected day
def predict_hour(model):
	gantt_hour =[]
	max_value = max(x for x in model)
	for i in range(0,24):
		if model[i] > max_value*threshold_hour_factor:
			gantt_hour.append(i)
	gantt_hour =sorted(gantt_hour)
	return gantt_hour

def print_all_hour_vector():
	for i in range(0,appl):
		print "Appliance " +app_names[i]
		for j in range(0,7):
			print "day " + days_names[j]
			print hours_score[i][j]

def print_hour_vector(appl,day):
	print hours_score[appl][day]

def save_hour_vector(path):
	with open(path,'w') as files:
		for i in range(0,appl):
			files.write(app_names[i])
			files.write("\n")
			for j in range(0,7):
				files.write(days_names[j])
				files.write("\n")
				files.write(str(hours_score[i][j]))
				files.write("\n")
				files.write("\n")
			files.write("\n")
			files.write("\n")
			files.write("\n")



# -----------------------------------Function for days model --------------------------------------

#For a specific appliance , update its week day score 
def train_day_vector(appliance,day):
	global day_score
	if "5" in data['network'][0]['appliances'][appliance]['WeekFrequency'] and "2" in data['network'][0]['appliances'][appliance]['WeekEndFrequency']:  #if the appliance is active all days than all the day will have the same score
		for i in range(0,7):
			day_score[appliance][i]+= (learning_rate_week)  
	else:
		for i in range(0,7):
			day_score[appliance][i]*= (1-learning_rate_week)  #reduce past history weight
		day_score[appliance][day]+=learning_rate_week         #increase day score

def print_all_day_vector():
	for i in range(0,appl):
		print "appl " +app_names[i]
		print day_score[i]

def print_day_vector(appl):
	print day_score[appl]

# model is the day_score vector for a specific appliance, return the days of the week on which the specific appliance will we active
def predict_generic_day(model):
	gantt_day =[]
	max_value = max(x for x in model)
	for i in range(0,7):
		if model[i] > max_value* threshold_week_factor:
			gantt_day.append(i)
	gantt_day =sorted(gantt_day)
	return gantt_day

# model is the day_score vector for a specific appliance. Returns the weekdays on which the specific appliance will we active
# the prediction is based on the training set, depending on the week frequency of the user and so on the random days extracted 
# for building the dataset and the log the function may returns zero or more eligible days
def predict_week_day(model):
	gantt_day =[]
	max_value = max(x for x in model[0:5])
	for i in range(0,5):
		if model[i] > max_value* threshold_week_factor:
			gantt_day.append(i)
	gantt_day =sorted(gantt_day)
	return gantt_day

# model is the day_score vector for a specific appliance, return the weekend days of the week on which the specific appliance will we active
# the prediction is based on the training set, depending on the week frequency of the user and so on the random days extracted 
#for building the dataset and the log the function may returns zero or more eligible days
def predict_week_end_day(model):
	gantt_day =[]
	max_value = max(x for x in model[5:7])
	for i in range(5,7):
		if model[i] > max_value* threshold_week_factor:
			gantt_day.append(i)
	gantt_day =sorted(gantt_day)
	return gantt_day
	
# model is the day_score vector for a specific appliance, return 1 if,for the specific day requested from the aggregator, the appliance will be active
def is_day_predicted(model,day):
	days= predict_generic_day(model)
	for d in days:
		if d == day:
			return 1
	return 0

# model is the day_score vector for a specific appliance, return 1 if,for the specific weekend day requested from the aggregator, the appliance will be active
def is_week_day_predicted(model,day):
	days= predict_week_day(model)
	for d in days:
		if d == day:
			return 1
	return 0

# model is the day_score vector for a specific appliance, return 1 if,for the specific day requested from the aggregator, the appliance will be active
def is_weekend_day_predicted(model,day):
	days= predict_week_end_day(model)
	for d in days:
		if d == day:
			return 1
	return 0

def save_day_vector(path):
	with open(path,'w') as files:
		for i in range(0,appl):
			files.write(app_names[i])
			files.write("\n")
			files.write("\n")
			files.write(str(day_score[i]))
			files.write("\n")
			files.write("\n")
			files.write("\n")

#--------------------------------------------------------WRITE THE TENTATVE GANTT----------------------------------------------------------------------

def write_tentative_gantt(input_gantt,day):
	data = read_json(input_gantt)   #read a blank gantt to be filled with predicted time intervals of each appliance for that day
	gantt_name = "./Users_Profiles/"+profile+"/"+"gantt.json"
	print_all_day_vector()
	print_all_hour_vector()
	for i in range(0,appl):
		if is_weekend_day_predicted(day_score[i],day) or is_week_day_predicted(day_score[i],day):
			print "Appliance "+ app_names[i] + " will be active on " + days_names[day]
			print "on the hours"
			print predict_hour(hours_score[i][day])
			os.system("rm -f "+gantt_name)
			
			interval=extract_interval(predict_hour(hours_score[i][day]))  #this function return a list interval =[[interval1],[interval2]...] with predicted intervals for the i-th appliance for the aggregator day


			new_interval= copy.deepcopy(data['appliance_'+str(i)])   #temporary variable to expand the appliance list of intervas in the gantt

			from_field=str(interval[0][0])+":00"    #creating new from and to field for the tentative gantt
			to_field = str(interval[0][1])+":00"
			data['appliance_'+str(i)][0]['from']=from_field
			data['appliance_'+str(i)][0]['to']=to_field

			write_json(gantt_name,data)     #write the first interval
			data = read_json(gantt_name)	#read data again
			if len(interval)==1:
				continue
			else:   
				for j in range(1,len(interval)):   #expand the appliance gantt field with the new intervals
					data['appliance_'+str(i)].extend(new_interval)
				write_json(gantt_name,data)
				data = read_json(gantt_name)

				for j in range(1,len(interval)): # write the from,to field of the new intervals
					from_field=str(interval[j][0])+":00"
					to_field = str(interval[j][1])+":00"
					data['appliance_'+str(i)][j]['from']= from_field
					data['appliance_'+str(i)][j]['to']= to_field
			
				write_json(gantt_name,data) #finallly write the modified gantt

		else:
			data['appliance_'+str(i)][0]['from']="100:00"
			data['appliance_'+str(i)][0]['to']="100:00"
			write_json(gantt_name,data)     #write the first interval

#This function, given a vector of predicted hours for the predicted for a specific appliance return  a vector interval = [[interval1],[interval2]...]
def extract_interval(vec):
	count =0
	interval=[]
	if len(vec)==1:
		interval.append([vec[0],vec[0]+1])
		return interval
	if len(vec)==2: #if only two hours x,y are predicted for that day 
		if vec[1]-vec[0] >6:  #if their difference in more than 6h we take them separately as two different intervals
			interval.append([vec[0],vec[0]+1])
			interval.append([vec[1],vec[1]+1])
			return interval
		else:					#else we take them as a single interval
			interval.append([vec[0],vec[1]])
			return interval

	for i in range(0,len(vec)):
		if i ==len(vec)-1 and count==0: #significa ultimo elemento del vettore e' un intervallo singolo di 1 ora
			interval.append([vec[i],vec[i]+1])
			return interval
		
		if i ==len(vec)-1 and count!=0: #significa ultimo elemento del vettore e' l'ultimo elemento di un intervallo
			interval.append([vec[i-count],vec[i]])
			return interval

		if vec[i+1] - vec[i] > 1:
			if count ==0: #intervallo e' una singola ora ed e' in un punto a caso del vettore
				interval.append([vec[i],vec[i]+1])
				continue
			interval.append([vec[i-count],vec[i]])
			count =0
			continue

		count+=1


#--------------------------------------------------------MAIN----------------------------------------------------------------------

# ---------------Gettin profile and day from user input ----------------------

profiles=["single_man","single_woman","couple","couple_one_child","couple_more_one_child","shared_apartment"]
days_names=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

n =raw_input("EA-SIM log simulator >>  Select a profile : (1) Single Man , (2) Single Woman, (3) Couple, (4) Family with one child, (5) Family with more than one child, (6) Shared Apartment ")
profile = profiles[int(n)-1]
print "EA-SIM log simulator >> Profile selected : "+profile
path = "./Users_Profiles/"+profile+"/"
d =raw_input("EA-SIM log simulator >>  Select a day for the prediction : (1) Monday, (2) Tuesday, (3) Wednesday, (4) Thursday, (5) Friday (6) Saturday (7) Sunday ")
day_to_predict = int(d)-1
print "EA-SIM log simulator >> Day to predict : "+days_names[day_to_predict]

#-------------- Read JSON file -------------------------

json_path=path+profile+"_network_description.json"
blank_gantt_path = path+"blank_gantt.json"
data = read_json(json_path)

#------------ Create log.csv file ---------------

future_log_path = path+"/"+profile+"_future_log.csv"
past_log_path = path+"/"+profile+"_past_log.csv"
os.system("rm -f "+future_log_path)
os.system("rm -f "+past_log_path)
future_log=open(future_log_path,'w')
future_log.close()

past_log=open(past_log_path,'w')
past_log.close()


#------------------Variables ----------------------------

appl =len(data['network'][0]['appliances'])  #extract the number of appliances defined
nweek = 1 			   #number of week for the future log
nweek_past = 2	   #number of the week for training the system 
app_names =[""]*appl   #will conains the names of the appliances
app_class =[""]*appl   #will conains the names of the appliances
app_days = [""]*appl   #will contains the days of appliances activation for each week
app_times =[""]*appl   #will contain the time selected for each appliance, will be a list of list (a matrix where the row index indicate the appliance and the column indicate the day)

dist=[[0 for x in xrange(24)] for x in xrange(appl)]  #row i will contain the probability density function of activation timefor the i-th appliance 

# ----------------- Learning Variables ---------------

learning_rate_hour = 0.2   # learning rate for hours
border_effect_rate = 0.7   # border factor for prevent the border effect on hours
threshold_hour_factor = 0.9 # threshold used for decide wich hour win above all
threshold_week_factor = 0.6 # threshold used for decide wich day/days win above all
learning_rate_week = 0.2     #learning rate for days

# hourscore[i][j][k] will contains the score of the i-th appliance, of the j-th day of the k-th hour slot
hours_score =[[[0.0 for k in xrange(24)] for j in xrange(7)] for i in xrange(appl)]  
# day_score[i][j] will contain the score of the i-th appliance for the j-th day 
day_score = [[0.0 for j in xrange(7)] for i in xrange(appl)] 


# ------------ Read Appliance probability csv file ------------------

for i in range(0,appl):
	count =0;
	app_names[i] = str(data['network'][0]['appliances'][i]['Name'])  	  #get appliance name
	app_class[i]= str(data['network'][0]['appliances'][i]['Name']).split("__")[0]
	csv_file = "./Appliances_Probabilities/"+app_class[i]+"_prob.csv"
	with open(csv_file, 'rb') as csvfile: 								#read the time probability distribution for that profile and save it in the vector dist[]
		spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
		for row in spamreader:
			dist[i][count]=float((row[0].split("\t"))[1].replace(",","."))
			count+=1


# ------------- Creating the past log to train the system  ----------------

for w in range(0,nweek_past):
	write_week_start(w+1,past_log_path)
	for a in range(0,appl):   #For the w-th week, for the a-th appliance first extracts the week and weekend frequency and then calculate the day in which will be active and the times
		frequency_week= int(data['network'][0]['appliances'][a]['WeekFrequency'])          	   #get week frequency of the appliance
		frequency_week_end = int(data['network'][0]['appliances'][a]['WeekEndFrequency'])  	   #get weekeng frequency of the appliance
		t_index=get_days(frequency_week,frequency_week_end,profile)							   #return the indexes( 0= Monday, 1 = Tuesday, etc) of the picked day for the appliance
		app_times[a]=get_time(dist[a],t_index)										#return for each appliance a [0]*7 vector where each index represent a day, containing the activation time at i-th day
	for i in range(0,7):   #for each day of the week create an hypotetical log
	 	write_day_on_log(days_names[i],past_log_path)
	 	for j in range(0,appl):												   
	 		if app_times[j][i]:
	 			write_row_on_log(app_names[j],app_times[j][i],past_log_path)
	 			train_hour_vector(j,i,int(app_times[j][i]))
	 			train_day_vector(j,i)
	 			
	 	write_end_day(past_log_path)
	write_end_week(past_log_path)

#----------------- End of past log creation ----------------------


# -------------Start creating the 'future' log file ----------------

for w in range(0,nweek):
	write_week_start(w+1,future_log_path)
	for a in range(0,appl):   #For the w-th week, for the a-th appliance first extracts the week and weekend frequency and then calculate the day in which will be active and the times
		frequency_week= int(data['network'][0]['appliances'][a]['WeekFrequency'])          	   #get week frequency of the appliance
		frequency_week_end = int(data['network'][0]['appliances'][a]['WeekEndFrequency'])  	   #get weekeng frequency of the appliance
		t_index=get_days(frequency_week,frequency_week_end,profile)							   #return the indexes( 0= Monday, 1 = Tuesday, etc) of the selected day for the appliance
		app_times[a]=get_time(dist[a],t_index)										#return for each appliance a [0]*7 vector where each index represent a day, containing the activation time at i-th day
		# print "APP " +app_names[a]
		# print "APP TIME " +str(app_times[a])
	for i in range(0,7):   #for each day of the week create an hypotetical log
		write_day_on_log(days_names[i],future_log_path)
	 	for j in range(0,appl):												   
	 		if app_times[j][i]:
	 			write_row_on_log(app_names[j],app_times[j][i],future_log_path)
	 			train_hour_vector(j,i,int(app_times[j][i]))
	 			train_day_vector(j,i)

	 	write_end_day(future_log_path)
	write_end_week(future_log_path)


#Save the day and hours score vector in two separate files in the profile folder
save_hour_vector(path+"hour_vector")
save_day_vector(path+"day_vector")

#Write the tentative gantt for the day 'day_to_predict'
write_tentative_gantt(blank_gantt_path,day_to_predict)

#Copy the generated gantt file to the Tmp_Gantt directory of the system, in order to allow the creation and saving of the gantt files resulting from the combinations
to_path=os.path.abspath(os.path.join(os.getcwd(), os.pardir))+"/Tmp_Gantt/gantt.json"  
from_path = path+"gantt.json"
os.system("cp -f "+from_path +" "+to_path)

#Copy the network_description.json file to the Tmp_Gantt directory of the system, in order to allow the creation and saving of the gantt files resulting from the combinations
to_path= to_path.replace("gantt","network_description")
from_path= from_path.replace("gantt",profile+"_network_description")
os.system("cp -f "+from_path +" "+to_path)

#Copy the network_description.json file to the EA-SIM_2.0 directory in orded to have all the files coherents along all the system directories.
#We don't pass the predicted gantt.json file to EA-SIM_2.0 because EA-SIM will be called from the learn_save_simulate.py script which will pass the gantt automatically to EA-SIM
to_path= to_path.replace("Tmp_Gantt","EA-SIM2.0")
os.system("cp -f "+from_path +" "+to_path)
