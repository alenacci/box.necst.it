import json                 #File: create_appliances.py      
import shlex                #Author: Giovanni Bettinazzi                 
import subprocess           #email: g.bettinazzi@gmail.com
import os                 
import sys 
import shutil
import glob
import datetime
import smtplib
import re
from pprint import pprint


#------------------------------------------------------------Checking if easim2.0.py has forwarded the silent mode-----------------------------------------------------------------------------------------------

silent = 0
if(len(sys.argv)>=2):  #easim2.0.py has forwarded the sylent flag
    silent = 1
#-------------------------------------------------------------------Utility and GET functions ------------------------------------------------------------------------------------------------


#Elaborate time from hh:mm format to seconds format		
def elaborate_time(string):
    time = string.split(":")                            
    time_final = (int(time[0])*60 + int(time[1]))*60  
    return time_final

#------------------------------------------------------------------Writing funcions ------------------------------------------------------------------------------------------------

#Write defines and includes in the .cpp file
def write_preambolo():
    out_file.write("#include \"systemc\"")
    out_file.write("\n")
    out_file.write("using namespace sc_core;"+"\n"+"using namespace sc_dt;"+"\n"+"using namespace std;"+"\n")
    out_file.write("#include \"tlm.h\"")
    out_file.write("\n")
    out_file.write("#include \"tlm_utils/simple_initiator_socket.h\"")
    out_file.write("\n")
    out_file.write("#include \"tlm_utils/simple_target_socket.h\"")
    out_file.write("\n")
    out_file.write("#include \"iostream\"")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\n")

#Write the appliance module 
def write_appliance(string):
    out_file.write("template<unsigned int ID_APPLIANCE, unsigned int START, unsigned int END>")
    out_file.write("\n")
    out_file.write("class Appliance"+str(string)+": public sc_module")
    out_file.write("\n")
    out_file.write("{")
    out_file.write("\n")
    out_file.write("public:")
    out_file.write("\n")
    out_file.write("\ttlm_utils::simple_initiator_socket<Appliance"+str(string)+"> socket;")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\tSC_CTOR(Appliance"+str(string)+") : socket(\"socket\")")
    out_file.write("\n")
    out_file.write("\t{")
    out_file.write("\n")
    out_file.write("\t\tSC_THREAD(thread_process);")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\n")

#Write appliance private section
def write_private_section():
    out_file.write("private:")
    out_file.write("\n")
    out_file.write("\n")
    write_variables()
    out_file.write("\n")

#Write variables defined in the private section
def write_variables():
    out_file.write("\tint pt_current_index;")
    out_file.write("\n")
    out_file.write("\tint pt_last_index;")
    out_file.write("\n")
    out_file.write("\tint power_trace[END];")
    out_file.write("\n")
    out_file.write("\tint app_initialized;")
    out_file.write("\n")
    out_file.write("\tint app_activated;")
    out_file.write("\n")
    out_file.write("\tbool elastic;")
    out_file.write("\n")
    out_file.write("\n")

#Write a useful function in the .h file to extract the power trace from the .csv file
def write_my_split():
    out_file.write("\t\tvector<string> my_split(string src, char delim)")
    out_file.write("\n")
    out_file.write("\t{")	
    out_file.write("\n")
    out_file.write("\t\tvector<string> result;")
    out_file.write("\n")
    out_file.write("\t\tstring::size_type startPos = 0, endPos = 0;")
    out_file.write("\n")
    out_file.write("\t\tdo")
    out_file.write("\n")
    out_file.write("\t\t{")
    out_file.write("\n")
    out_file.write("\t\t\tendPos = src.find_first_of(delim,startPos);")
    out_file.write("\n")
    out_file.write("\t\t\tstring::size_type length = endPos - startPos;")
    out_file.write("\n")
    out_file.write("\t\t\tif(length != 0)")
    out_file.write("\n")
    out_file.write("\t\t\t\tresult.push_back( src.substr(startPos,length) );")
    out_file.write("\n")
    out_file.write("\t\t\tstartPos = endPos + 1;")
    out_file.write("\n")
    out_file.write("\t\t}")
    out_file.write("\n")
    out_file.write("\t\twhile(endPos != string::npos);")
    out_file.write("\n")
    out_file.write("\t\treturn result;")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\n")

#Write the appliance initialization function that initialize the variables and get the power trace from the .csv file
def write_init_power_trace(string,out_file):    
    out_file.write("\t void init_app()")
    out_file.write("\n")
    out_file.write("\t{")
    out_file.write("\n")
    out_file.write("\t\tapp_activated = 0;")
    out_file.write("\n")
    out_file.write("\t\t\tif (app_initialized)")
    out_file.write("\n")
    out_file.write("\t\t\t\treturn;")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\tapp_initialized = 1;")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\tcout << \"Loading appliance ID \" << ID_APPLIANCE << \" power trace...\\n \";")
    out_file.write("\n")
    out_file.write("\tstring line;")
    out_file.write("\n")
    out_file.write("\tstring file_path = \"./Archive/Flowfiles/"+string+".csv\";")
    out_file.write("\n")		
    out_file.write("\tifstream myfile (file_path.c_str());")
    out_file.write("\n")
    out_file.write("\tint line_counter = 0;")
    out_file.write("\n")
    out_file.write("\tif (myfile.is_open())")
    out_file.write("\n")
    out_file.write("\t\t{")
    out_file.write("\n")
    out_file.write("\t\t\twhile ( getline (myfile,line) )")
    out_file.write("\n")
    out_file.write("\t\t\t{")
    out_file.write("\n")
    out_file.write("\t\t\tif (line[0] == '#') continue;")
    out_file.write("\n")
    out_file.write("\t\t\tif (line_counter == END-1) break;")
    out_file.write("\n")
    out_file.write("\t\t\tstd::vector<std::string> current_line;")
    out_file.write("\n")
    out_file.write("\t\t\tcurrent_line = my_split(line, ';');")
    out_file.write("\n")
    out_file.write("\t\t\tpower_trace[line_counter] = atoi(current_line[0].c_str());")
    out_file.write("\n")
    out_file.write("\t\t\tline_counter++;")
    out_file.write("\n")
    out_file.write("\t\t\t}")
    out_file.write("\n")
    out_file.write("\t\tmyfile.close();")
    out_file.write("\n")
    out_file.write("\t\tpt_last_index = line_counter-1;")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\telse cout << \"Unable to open file \" << file_path << \"...\";")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\tfor(int i=line_counter; i < END; i++){")
    out_file.write("\n")
    out_file.write("\t\t power_trace[i]=0;")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\n")
  

#Write the behavior for all the appliances
def write_behavior(string, cycle):
    out_file.write("\tint appliance_behaviour(int instant)")
    out_file.write("\n")
    out_file.write("\t{")
    out_file.write("\n") 	
    if( (string[0])['continuous'] =='TRUE'):
       out_file.write("\n")
       out_file.write("\t\treturn power_trace[ instant-START ];")  #Write the behaviour for all the appliances that are ON the whole day time
       out_file.write("\n")
       out_file.write("\n")
       out_file.write("\t}")
       out_file.write("\n")
       out_file.write("\n")
       return;
    else:
     for i in range(0,len(string)):     
       t_start = elaborate_time((string[i])['from'])
       #t_end = elaborate_time((string[i])['to'])
       t_end = t_start + cycle
       out_file.write("\n")
       out_file.write("\t\tif( (instant % 86400) >= ("+str(t_start)+") && (instant % 86400)<= ("+str(t_end)+") )")
       out_file.write("\n")
       out_file.write("\t\t{")
       out_file.write("\n")
       out_file.write("\t\t\treturn power_trace[((instant % 86400) - ("+str(t_start)+")) ] ;")
       out_file.write("\n")
       out_file.write("\t\t}")
       out_file.write("\n")
    out_file.write("\t\treturn 0;")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("\n")
             

#Write the thread_process() function
def write_thread_process():
    out_file.write("\tvoid thread_process()")
    out_file.write("\n")
    out_file.write("\t{")
    out_file.write("\n")
    out_file.write("\t\tinit_app();")
    out_file.write("\n")
    out_file.write("\t\ttlm::tlm_generic_payload *transaction = new tlm::tlm_generic_payload;")
    out_file.write("\n")
    out_file.write("\t\tsc_time delay = sc_time(1, SC_NS);")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\tfor(int i = START; i < END; i++)")
    out_file.write("\n")
    out_file.write("\t\t{")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\t\tint data = appliance_behaviour(i);")
    out_file.write("\n")
    out_file.write("\t\t\tsc_time delay = sc_time(1, SC_NS);")
    out_file.write("\n")
    out_file.write("\n")
    if(silent==0):
        out_file.write("\t\t\tcout << \"$EASIM> \" << sc_time_stamp() << \" :: \" << \"Appliance[\"<< ID_APPLIANCE << \"] :: \" << \"CURRENT_REQUEST\" << \" :: {\" << data << \"}.\\n \";")
        out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_command(tlm::TLM_WRITE_COMMAND);")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_address(ID_APPLIANCE);")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_data_ptr(reinterpret_cast<unsigned char*>(&data));")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_data_length(4);")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_streaming_width(4); // = data_length to indicate no streaming")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_byte_enable_ptr(0); // 0 indicates unused")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_dmi_allowed(false); // Mandatory initial value")
    out_file.write("\n")
    out_file.write("\t\t\ttransaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\t\tsocket->b_transport(*transaction, delay);  // Blocking transport call")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\t\t// Initiator obliged to check response status and delay")
    out_file.write("\n")
    out_file.write("\t\t\tif (transaction->is_response_error())")
    out_file.write("\n")
    out_file.write("\t\t\t\tSC_REPORT_ERROR(\"TLM-2\", \"Response error from b_transport\");")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\t\t\twait(delay);")
    out_file.write("\n")			
    out_file.write("\t\t}")
    out_file.write("\n")
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("};")
    out_file.write("\n")		


#---------------------------------------------------------------- end of Writing functions ----------------------------------------------------------------------------------


#----------------------------------------------------------------------- Main -----------------------------------------------------------------------------------------------


#-----------------------------------------------------------Writing the file applianceName.h --------------------------------------------------------------------------------      
#gantt.json contains appliances attributes
with open("gantt.json",'r') as json_file:
      data = json.load(json_file) 
      json_file.close()

#network_description.json contains appliances attributes
with open("network_description.json",'r') as json_file:
      data2 = json.load(json_file) 
      json_file.close()


appl = len(data2['network'][0]['appliances']) 	#len(data['network'][0]['appliances']) = number of appliances defined
name =""
cycle = 0

for i in range(0,appl):  
             class_name = str(data2['network'][0]['appliances'][i]['Name']).split("__")       #contain the c++ Class Name of the i-th appliance in network_description.json , if there are more than one appliance per type just get the class name
             name =  str(data2['network'][0]['appliances'][i]['Name'])                        # contain the Name field of the i-th appliance
             cycle= int(data2['network'][0]['appliances'][i]['Cycle'])                        #contain the Cycle field of the i-th appliance in network_description.json
             nome_file = "./Archive/Appliance/Appliance"+(name)+".h"  
             out_file= open(nome_file,"w")		
             write_preambolo()			                
             write_appliance(name)                               
             write_private_section()                                
             write_my_split()
             write_init_power_trace(class_name[0],out_file)               
             index = "appliance_"+str(i)
             write_behavior(data[index],cycle)   #data[index] contains the list of attributes for the i-th appliance declared in gantt.json (continuois,elastic,from,to)
             write_thread_process()
             out_file.close() 
             #print("EA-SIM 2.0 >>  Created appliance "+name+" with id = "+str(i))

