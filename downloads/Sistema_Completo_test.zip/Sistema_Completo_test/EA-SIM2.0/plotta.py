import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt

data = np.genfromtxt('./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.csv', delimiter=';', names=['x', 'y'])
aggregator = 500
plt.xlabel('Time[h]')
plt.ylabel('Power request [W]')
plt.title('System load profile')
plt.grid(True)
plt.axis([0, 23, 0, 2000])

plt.axhline(y=aggregator, xmin=0, xmax=23,c="green", label='Aggregator')
plt.plot(data['x'], data['y'], color='r', label='Simulated value')
plt.legend()
plt.savefig('./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.svg', dpi=1000, facecolor='w', edgecolor='w', orientation='portrait', papertype=None,transparent=False, bbox_inches=None, pad_inches=0.1,frameon=None)