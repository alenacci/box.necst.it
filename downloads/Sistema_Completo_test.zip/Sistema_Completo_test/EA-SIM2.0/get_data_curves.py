import shlex								   #File: get_data_curves.py 
import subprocess     						   #Author: Giovanni Bettinazzi
import os                                      #email: g.bettinazzi@gmail.com
import sys
import shutil
import glob
import datetime
import smtplib
import math
import json
import random 
import matplotlib as mpl
import numpy as np
import matplotlib.pyplot as plt
#-------------------------------------------------------------------------------Input length control------------------------------------------------------------------------------------------------
if len(sys.argv) <= 1:
	print "EA-SIM 2.0 >> Error: Missing parameters [N_APPLIANCES][N_BATTERIES][REDUCTION]"
	sys.exit(-1)
elif len(sys.argv) <=2:
    print "EA-SIM 2.0 >> Error: Missing parameters [N_BATTERIES][REDUCTION]"
    sys.exit(-1)
elif len(sys.argv) <=3:
    print "EA-SIM 2.0 >> Error: Missing parameter [REDUCTION]"
    sys.exit(-1)
    
#-------------------------------------------------------------------------------Get input parameters-----------------------------------------------------------------------------------------------
silent = 0
number_of_appliances = int(sys.argv[1])
number_of_batteries = int(sys.argv[2])
amount = int(sys.argv[3])
if(len(sys.argv)==5):  #easim2.0.py has forwarded the sylent flag
	silent = 1


#-------------------------------------------------------------------------------Variables definitions----------------------------------------------------------------------------------------------
_GNUPLOT_PATH = "gnuplot"
cost= [0]*2
powergenerator_currentdrain_total = []
powergenerator_currentdrain_grid = []
powergenerator_currentdrain_solar = []
powergenerator_overalldrain = []
powergenerator_max_current_solar = []
appliance_current_request = [[] for x in range(0,number_of_appliances)]
battery_level = [[] for x in range(0,number_of_batteries)]
battery_energy = [[] for x in range(0,number_of_batteries)]
battery_state = [[] for x in range(0,number_of_batteries)]
iterator1 = range(0,number_of_appliances) 
iterator2 = range(0,number_of_batteries) 
_sprt_ = ";" #separator	

#-------------------------------------------------------------------------------Export functions--------------------------------------------------------------------------------------------------
#Export 'content' in a .csv file
def export_to_csv(filename, content):
	if len(content) > 0:
		filename += ".csv"
		#print("EA-SIM 2.0 : Writing " + filename + "...")
		out_file = open(filename,"w")
		tmp = ""
		for c in content:
			tmp += c + "\n"
		out_file.write(tmp)
		out_file.close()

#Export 'content' in a .dat file
def export_to_dat(filename, content):
	if len(content) > 0:
		filename += ".dat"
		#print("EA-SIM 2.0 : Writing " + filename + "...")
		out_file = open(filename,"w")
		tmp = ""
		for c in content:
			tmp += c.replace(_sprt_, "\t") + "\n"
		out_file.write(tmp)
		out_file.close()

#Create a .dat file with the average system energy consumption value
def export_to_average_dat(filename,content):
	if len(content) > 0:
		filename += "AVERAGE.dat"
		#print("EA-SIM 2.0 : Writing " + filename + "...")
		out_file = open(filename,"w")
		tmp = ""
		average_power = 0
		for c in content:
			average_power += float(c.split(_sprt_)[1])
		average_power*= 2.777778e-7	#conversion from Ws to kWh 
		out_file.write(str(average_power)+ " kWh")
		out_file.close()

#Create three .dat files with the consumption in F1 and F23 TOU
def export_to_cost_dat():
	filename=""
	filename += "./Data_and_curves/Last_Simulation_Results/System/resulting_cost.dat"
	out_file = open(filename,"w")
	tmp = "F1" +"\t" +str(cost[0]) + "\n"+"F23" +"\t" +str(cost[1])
	out_file.write(tmp)
	out_file.close()
	filename=""
	filename += "./Data_and_curves/Last_Simulation_Results/System/resulting_costf1.dat"
	out_file = open(filename,"w")
	tmp = "F1" +"\t" +str(cost[0])
	out_file.write(tmp)
	out_file.close()
	filename=""
	filename += "./Data_and_curves/Last_Simulation_Results/System/resulting_costf23.dat"
	out_file = open(filename,"w")
	tmp = "F23" +"\t" +str(cost[1])
	out_file.write(tmp)
	out_file.close()


#Create system power profile curve in PNG (flag = 1) or PDF (flag =0) format
def export_to_img_pdf_pwgen(filename,content,amount,flag):
	average_power = 0
	for c in content:
			average_power += float(c.split(_sprt_)[1])
	average_power*= 2.777778e-7	#conversion from Ws to kWh
	average_power = round(average_power,3)
	script = ""
	if(flag):
		script += 'set terminal png enhanced size 1280,1024' + '\n'
		script += 'set output "' + filename +'.png"' + "\n"
		script += 'set title "System consumption curve - energy consumption over selected time  = '+str(average_power)+' kWh" font "Times-Italic,18"' + "\n"
		script += 'set xlabel "Time [h]" font "Times-Italic,18"' + "\n"
		script += 'set ylabel \"Power consumption [W]\"  font "Times-Italic,18"' + "\n"
	else:
		script += 'set terminal pdf' + "\n"
		script += 'set output "' + filename +'.pdf"' + "\n"
		script += 'set title "System consumption curve - energy consumption over selected time  = '+str(average_power)+' kWh" font "Times-Italic,7"' + "\n"
 		script += 'set xlabel "Time [h]" font "Times-Italic,8"' + "\n"
	 	script += 'set ylabel \"Power consumption [W]\"  font "Times-Italic,8"' + "\n"

	script += 'set grid' + "\n"	
	script+= 'set key Right ' + "\n"
	script += 'set xtics 1' + "\n"
	script += 'plot "' + filename + '.dat" title \'Power consumption\' with lines,'+str(amount)+" title 'Aggregator request' with lines " + "\n"
	scriptName = "tmpscript.gnu"

	out_file = open(scriptName,"w")
	out_file.write(script)
	out_file.close()	
	os.system(_GNUPLOT_PATH + ' ' + scriptName)
	os.system('rm ' + scriptName)
	#plotting using matplotlib
	# data = np.genfromtxt('./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.csv', delimiter=';', names=['x', 'y'])
	# aggregator = 500
	# plt.xlabel('Time[h]')
	# plt.ylabel('Power request [W]')
	# plt.title('System load profile')
	# plt.grid(True)
	# plt.axis([0, 23, 0, 2000])

	# plt.axhline(y=aggregator, xmin=0, xmax=23,c="green", label='Aggregator')
	# plt.plot(data['x'], data['y'], color='r', label='Simulated value')
	# plt.legend()
	# plt.savefig('./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid.svg', dpi=1000, facecolor='w', edgecolor='w', orientation='portrait', papertype=None,transparent=False, bbox_inches=None, pad_inches=0.1,frameon=None)


#Create battery level evolution curve in PNG (flag = 1) or PDF (flag =0) format
def export_to_img_pdf_battery(filename,flag):
	script = ""
	if(flag):
		script += 'set terminal png enhanced size 1280,1024' + '\n'
		script += 'set output "' + filename +'.png"' + "\n"
		script += 'set title "Battery level evolution" font "Times-Italic,18"' + "\n"
		script += 'set xlabel "Time [h]" font "Times-Italic,18"' + "\n"
		script += 'set ylabel \"Level [%]\"  font "Times-Italic,18"' + "\n"
	else:
		script += 'set terminal pdf' + "\n"
		script += 'set output "' + filename +'.pdf"' + "\n"
		script += 'set title "Battery level evolution" font "Times-Italic,9"' + "\n"
		script += 'set xlabel "Time [h]" font "Times-Italic,9"' + "\n"
		script += 'set ylabel \"Level [%]\"  font "Times-Italic,9"' + "\n"

	script += 'set yrange [0:104]' + "\n"
	script += 'set grid' + "\n"	
	script += 'set nokey' + "\n"
	script += 'set xtics 1' + "\n"
	script += 'plot "' + filename + '.dat" with lines' + "\n"
	scriptName = "tmpscript.gnu"

	out_file = open(scriptName,"w")
	out_file.write(script)
	out_file.close()	

	os.system(_GNUPLOT_PATH + ' ' + scriptName)
	os.system('rm ' + scriptName)

#Create appliances power profile curve in PNG (flag = 1) or PDF (flag =0) format
def export_to_img_pdf_appliance(filename,content,flag):
	average_power = 0
	for c in content:
			average_power += float(c.split(_sprt_)[1])
	average_power*= 2.777778e-7	#conversion from Ws to kWh
	average_power = round(average_power,3)
	script = ""
	if(flag):
		script += 'set terminal png enhanced size 1280,1024' + '\n'
		script += 'set output "' + filename +'.png"' + "\n"
		script += 'set title "Appliance power profile - energy consumption over selected time = '+str(average_power)+' kWh" font "Times-Italic,18"' + '\n'
		script += 'set xlabel "Time [h]" font "Times-Italic,18"' + "\n"
		script += 'set ylabel \"Power consumption [W]\"  font "Times-Italic,18"' + "\n"
	else:
		script += 'set terminal pdf' + "\n"
		script += 'set output "' + filename +'.pdf"' + "\n"
		script += 'set title "Appliance power profile - energy consumption over selected time = '+str(average_power)+' kWh" font "Times-Italic,7"' + '\n'
		script += 'set xlabel "Time [h]" font "Times-Italic,8"' + "\n"
		script += 'set ylabel \"Power consumption [W]\"  font "Times-Italic,8"' + "\n"

	script += 'set grid' + "\n"	
	script += 'set xtics 1' + "\n"
	script += 'set nokey' + "\n"
	script += 'plot "' + filename + '.dat" with lines' + "\n"
	scriptName = "tmpscript.gnu"

	out_file = open(scriptName,"w")
	out_file.write(script)
	out_file.close()	
	os.system(_GNUPLOT_PATH + ' ' + scriptName)
	os.system('rm ' + scriptName)

#Create cost histograms in PNG (flag = 1) or PDF (flag =0) format
def create_cost_histogram(filename,content,flag):
	script=""
	if(flag):
		script += 'set terminal png truecolor enhanced size 1280,1024' + '\n'
		script += 'set output "' + filename +'.png"' + "\n"
		script += 'set title "Resulting cost per Time of use periods (TOU)" font "Times-Italic,18"' + "\n"
		script += 'set xlabel "Time of use periods" font "Times-Italic,18"' + "\n"
		script += 'set ylabel \"Cost [euro]\"  font "Times-Italic,18"' + "\n"
	else:
		script += 'set terminal pdf' + "\n"
		script += 'set output "' + filename +'.pdf"' + "\n"
		script += 'set title "Resulting cost per Time of use periods (TOU)" font "Times-Italic,9"' + "\n"
		script += 'set xlabel "Time of use periods" font "Times-Italic,9"' + "\n"
		script += 'set ylabel \"Cost [euro]\"  font "Times-Italic,9"' + "\n"
	script += 'set grid y' + "\n"
	script += 'set xtics format " "'+"\n"	
	script+= 'set nokey ' + "\n"
	script += 'set style data histograms' + "\n"
	script += 'set style histogram cluster gap 1' + "\n"
	script += 'set style fill solid 1.0 border rgb "black"' + "\n"
	script += 'plot newhistogram "F1" at 0, "' + filename + 'f1.dat" u 2 linecolor rgb "orange-red",\\' +"\n" + 'newhistogram "F23" at 1, "' + filename + 'f23.dat" u 2 linecolor rgb "royalblue"' +"\n"
	scriptName = "tmpscript.gnu"
	s = filename+'f1.dat'
	s1 = filename +'f23.dat'
	out_file = open(scriptName,"w")
	out_file.write(script)
	out_file.close()	
	os.system(_GNUPLOT_PATH + ' ' + scriptName)
	os.system('rm ' + scriptName)
	



#Create dat, csv, png and pdf files for appliances, power generator and batteries
def export_to_file(filename, content):
	export_to_csv(filename, content)
	export_to_dat(filename, content)
	if "battery" in filename:
		export_to_img_pdf_battery(filename,0) #pdf
		export_to_img_pdf_battery(filename,1) #png
	elif "current_request" in filename:
		export_to_img_pdf_appliance(filename,content,0) #pdf
		export_to_img_pdf_appliance(filename,content,1) #png
	else:
		export_to_img_pdf_pwgen(filename,content,amount,0) #pdf
		export_to_img_pdf_pwgen(filename,content,amount,1) #png
		export_to_average_dat(filename,content)



#-------------------------------------------------------------------------------Get functions ------------------------------------------------------------------------------------------------
#Elaborate time from SystemC ns format to seconds
def get_time(line):
	t_s = float(line[:line.find(" :: ")].replace(" us","000").replace("ns","").replace("s","").strip())
	t_h = t_s / 3600
	return str(t_h)

#Control the aggregator request fullfilment from EnergyBox message and create a file with a 0 if the request is not fullfilled, 1 otherwise
def get_request_fullfilment(line):
	if ("WARNING :: REQUEST NOT FULFILLED") in line:
		#print "EA-SIM 2.0 >> WARNING : Aggregator request not fulfill for the selected interval"
		export_to_csv("./Data_and_curves/Last_Simulation_Results/System/Aggregator_fullfilment","0")
	elif("WARNING :: REQUEST FULFILLMENT") in line:
#		print "EA-SIM 2.0 >> WARNING : Aggregator request fulfilled for the selected interval"
		export_to_csv("./Data_and_curves/Last_Simulation_Results/System/Aggregator_fullfilment","1")

#Get appliances request
def get_appliance_current_request(line):
	for id in iterator1:
		if ("Appliance[" + str(id) + "] :: CURRENT_REQUEST") in line:
			#x = random.randint(70,90)
			val = float(line[line.find("{")+1:line.find("}")].strip())# * math.sin(math.radians(x))
			appliance_current_request[id].append(get_time(line) + _sprt_ + str(val))

#Get battery level data
def get_battery_level(line):
	for id in iterator2:
		if ("Battery[" + str(id)+ "] :: BATTERY_LEVEL") in line:
			val = line[line.find("{")+1:line.find("}")].strip()
			new_item = get_time(line) + _sprt_ + val

			if (len(battery_level[id]) > 0) and (battery_level[id][-1][:battery_level[id][-1].find(";")] == get_time(line)):
				battery_level[id].pop()	
			
			battery_level[id].append(new_item)

#Get battery energy data
def get_battery_energy(line):
	for id in iterator2:
		if ("Battery[" + str(id)+ "] :: BATTERY_ENERGY") in line:
			val = line[line.find("{")+1:line.find("}")].strip()
			new_item = get_time(line) + _sprt_ + val

			if (len(battery_energy[id]) > 0) and (battery_energy[id][-1][:battery_energy[id][-1].find(";")] == get_time(line)):
				battery_energy[id].pop()	

			battery_energy[id].append(new_item)

#Get battery state evolution
def get_battery_state(line):
	for id in iterator2:
		if ("Battery[" + str(id)+ "] :: BATTERY_STATE") in line:
			val = line[line.find("{")+1:line.find("}")].strip()
			new_item = get_time(line) + _sprt_ + val

			if (len(battery_state[id]) > 0) and (battery_state[id][-1][:battery_state[id][-1].find(";")] == get_time(line)):
				battery_state[id].pop()	

			battery_state[id].append(new_item)

#Get instant cost from EnergyBox messages
def get_cost(line):
	if "EnergyBox :: COST FOR F1" in line: 
		cost[0]=line[line.find("{")+1:line.find("}")].strip()

	elif "EnergyBox :: COST FOR F23" in line: 
		cost[1]=line[line.find("{")+1:line.find("}")].strip()

#Get PowerGenerator total drain
def get_powergenerator_currentdrain_total(line):
	if "PowerGenerator :: CURRENT_DRAIN_TOTAL" in line:
		val = int(line[line.find("{")+1:line.find("}")].strip())

		if len(powergenerator_currentdrain_total)>0 and powergenerator_currentdrain_total[-1].startswith(get_time(line)):
			saved_val = int(powergenerator_currentdrain_total[-1].replace(get_time(line) + _sprt_ , "").strip())
			if val > saved_val:
				powergenerator_currentdrain_total.pop()
				powergenerator_currentdrain_total.append(get_time(line) + _sprt_ + str(val))
		else:
			powergenerator_currentdrain_total.append(get_time(line) + _sprt_ + str(val))

#Get PowerGenerator current drain from grid
def get_powergenerator_currentdrain_grid(line):
	if "PowerGenerator :: CURRENT_DRAIN_GRID" in line:
		#x = random.randint(50,90)
		val = float(line[line.find("{")+1:line.find("}")].strip()) #* math.sin(math.radians(x))

		if len(powergenerator_currentdrain_grid)>0 and powergenerator_currentdrain_grid[-1].startswith(get_time(line)):
			saved_val = float(powergenerator_currentdrain_grid[-1].replace(get_time(line) + _sprt_ , "").strip())
			if val > saved_val:
				powergenerator_currentdrain_grid.pop()
				powergenerator_currentdrain_grid.append(get_time(line) + _sprt_ + str(val))
		else:
			powergenerator_currentdrain_grid.append(get_time(line) + _sprt_ + str(val))

#Get PowerGenerator current drain from solar source
def get_powergenerator_currentdrain_solar(line):
	if "PowerGenerator :: CURRENT_DRAIN_SOLAR" in line:
		val = int(line[line.find("{")+1:line.find("}")].strip())

		if len(powergenerator_currentdrain_solar)>0 and powergenerator_currentdrain_solar[-1].startswith(get_time(line)):
			saved_val = int(powergenerator_currentdrain_solar[-1].replace(get_time(line) + _sprt_ , "").strip())
			if val > saved_val:
				powergenerator_currentdrain_solar.pop()
				powergenerator_currentdrain_solar.append(get_time(line) + _sprt_ + str(val))
		else:
			powergenerator_currentdrain_solar.append(get_time(line) + _sprt_ + str(val))

#Get max current solar from PowerGenerator messages
def get_powergenerator_max_current_solar(line):
	if "PowerGenerator :: MAX_CURRENT_SOLAR" in line:
		val = int(line[line.find("{")+1:line.find("}")].strip())

		if len(powergenerator_max_current_solar)>0 and powergenerator_max_current_solar[-1].startswith(get_time(line)):
			saved_val = int(powergenerator_max_current_solar[-1].replace(get_time(line) + _sprt_ , "").strip())
			if val > saved_val:
				powergenerator_max_current_solar.pop()
				powergenerator_max_current_solar.append(get_time(line) + _sprt_ + str(val))
		else:
			powergenerator_max_current_solar.append(get_time(line) + _sprt_ + str(val))


#Get PowerGenerator current drain
def get_powergenerator_overalldrain(line):
	if "PowerGenerator :: OVERALL_DRAIN" in line:
		val = int(line[line.find("{")+1:line.find("}")].strip())

		if len(powergenerator_overalldrain)>0 and powergenerator_overalldrain[-1].startswith(get_time(line)):
			saved_val = int(powergenerator_overalldrain[-1].replace(get_time(line) + _sprt_ , "").strip())
			if val > saved_val:
				powergenerator_overalldrain.pop()
				powergenerator_overalldrain.append(get_time(line) + _sprt_ + str(val))
		else:
			powergenerator_overalldrain.append(get_time(line) + _sprt_ + str(val))

def create_directories():
	os.makedirs('./Data_and_curves/Last_Simulation_Results')
	os.makedirs('./Data_and_curves/Last_Simulation_Results/System')
	if(silent==0):
		os.makedirs('./Data_and_curves/Last_Simulation_Results/Appliances')
		os.makedirs('./Data_and_curves/Last_Simulation_Results/Battery')

#----------------------------------------------------------------------------------Main------------------------------------------------------------------------------------------------

#Oper dump file
f = open('dump.txt')
lines = f.readlines()
f.close()


#network_description.json contains appliances attributes, used to extract appliances names
with open("network_description.json",'r') as json_file:
      data = json.load(json_file) 
      json_file.close()

#Check if utility directories exist, if they don't then create them
if not os.path.exists('./Data_and_curves/Last_Simulation_Results'):
	create_directories()	
else: #If exists move them to another directory 
	if os.path.exists('./Data_and_curves/Previous_Simulation_Results'):
		os.system('rm -r ./Data_and_curves/Previous_Simulation_Results')
	os.system(' mv ./Data_and_curves/Last_Simulation_Results ./Data_and_curves/Previous_Simulation_Results')
	create_directories() 

os.system("cp gantt.json ./Data_and_curves/Last_Simulation_Results")  #copy the gantt.json file to the directory of the results

#-------------------------------------------------------------------------------Reading dump.txt------------------------------------------------------------------------------------------------
#----------------------------------------------if in silent mode (silent = 1) only power generator and system data are generated-----------------------------------
for line in lines:
	if line.startswith("$EASIM>") or line.startswith(" $EASIM"):
		line = line.replace("$EASIM>", "").strip()

		if(silent==0):
			get_appliance_current_request(line)   
			get_battery_level(line)
			#get_battery_energy(line)
			#get_battery_state(line)
			#get_powergenerator_currentdrain_total(line)
			#get_powergenerator_currentdrain_solar(line)
			#get_powergenerator_max_current_solar(line)
		get_powergenerator_currentdrain_grid(line)
	get_cost(line)
	get_request_fullfilment(line)

if(silent==0):
	print "EA-SIM 2.0 >> Creating Appliances Curves and Data"
	for id in iterator1:
		name = str(data['network'][0]['appliances'][id]['Name'])
		export_to_file("./Data_and_curves/Last_Simulation_Results/Appliances/"+name+"_current_request", appliance_current_request[id])

	# print "EA-SIM 2.0 >> Creating Battery Curves and Data"
	# for id in iterator2:
	# 	export_to_file("./Data_and_curves/Last_Simulation_Results/Battery/battery[" + str(id)+ "]_level", battery_level[id])
 #        #export_to_file("./Data_and_curves/Last_Simulation_Results/Battery/battery[" + str(id)+ "]_energy", battery_energy[id])
 #        #export_to_file("./Data_and_curves/Last_Simulation_Results/Battery/battery[" + str(id)+ "]_state", battery_state[id])
print "EA-SIM 2.0 >> Creating Power Generator Curves and Data"
#export_to_file("./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_total",powergenerator_currentdrain_total)
export_to_file("./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_grid",powergenerator_currentdrain_grid)
#export_to_file("./Data_and_curves/Last_Simulation_Results/System/powergenerator_currentdrain_solar",powergenerator_currentdrain_solar)
#export_to_file("./Data_and_curves/Last_Simulation_Results/System/powergenerator_max_current_solar",powergenerator_max_current_solar)
# print "EA-SIM 2.0 >> Creating Cost Istogram"
# export_to_cost_dat()
# create_cost_histogram("./Data_and_curves/Last_Simulation_Results/System/resulting_cost",cost,0)
# create_cost_histogram("./Data_and_curves/Last_Simulation_Results/System/resulting_cost",cost,1)