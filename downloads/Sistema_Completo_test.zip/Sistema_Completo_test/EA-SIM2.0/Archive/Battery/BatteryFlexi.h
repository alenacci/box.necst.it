#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

#include <vector>

template<unsigned int ID_BATTERY,unsigned int START,unsigned int END >
class BatteryFlexi : public sc_module
{
public:
	// TLM-2 socket, defaults to 32-bits wide, base protocol
//	tlm_utils::simple_target_socket_tagged<BatteryFlexi> *appliance_socket[NUMBER_OF_APPLIANCES]; 				// where it will send energy
	tlm_utils::simple_initiator_socket<BatteryFlexi> discharge_socket;
	tlm_utils::simple_initiator_socket<BatteryFlexi> recharge_socket;	
	tlm_utils::simple_target_socket<BatteryFlexi> cpu_socket;													// the cpu communication port

	SC_CTOR(BatteryFlexi) : cpu_socket("cpu_socket"), recharge_socket("recharge_socket"), discharge_socket("discharge_socket")
	{
		
		// Register callback for incoming b_transport interface method call
		cpu_socket.register_b_transport(this, &BatteryFlexi::CPU_b_transport);

		{
			// Getting battery data 
			cout << "Loading battery ID " << ID_BATTERY << " status data..\n";
			string line;
			string file_name = "battery_status_";
			string file_path = "./Archive/Flowfiles/";
			
			char ID_BATTERY_STR[5];
			sprintf(ID_BATTERY_STR, "%d", ID_BATTERY);
			file_name.append(ID_BATTERY_STR);
			file_name.append(".csv");
			file_path.append(file_name);

			// Getting battery status
			ifstream myfile(file_path.c_str());
			int line_counter = 0;
			if (myfile.is_open())
			{
				while ( getline (myfile,line) )
				{
					if (line[0] == '#') continue;

					std::vector<std::string> current_line;
					current_line = my_split(line, ';');

					battery_energy = atoi(current_line[0].c_str());
					battery_level = atoi(current_line[1].c_str());
					battery_state = atoi(current_line[2].c_str());
					MAX_ENERGY = atoi(current_line[3].c_str());
					RECHARGE = atoi(current_line[4].c_str());
					DISCHARGE = atoi(current_line[5].c_str());
					line_counter++;
				}
				myfile.close();
			}
			else {
				cout << "Unable to open file " << file_path << "...";
			}
		}

		{
			// Getting battery model 
			cout << "Loading battery ID " << ID_BATTERY << " model data..\n";
			string line;
			string file_name = "battery_energymodel_";
			string file_path = "./Archive/Flowfiles/";
			
			char ID_BATTERY_STR[5];
			sprintf(ID_BATTERY_STR, "%d", ID_BATTERY);
			file_name.append(ID_BATTERY_STR);
			file_name.append(".csv");
			file_path.append(file_name);

			// Getting battery model
			ifstream myfile(file_path.c_str());
			int line_counter = 0;
			if (myfile.is_open())
			{
				while ( getline (myfile,line) )
				{
					if (line[0] == '#') continue;

					std::vector<std::string> current_line;
					current_line = my_split(line, ';');

					if (line_counter==0){
						for (int z = 0; z < current_line.size(); z++)
						{
							energy_model_interval[z] = atoi(current_line[z].c_str());
						}

						energy_model_entry_number = current_line.size();
					}

					if (line_counter==1){
						for (int z = 0; z < current_line.size(); z++)
						{
							energy_model_coeff[z] = (double)(atof(current_line[z].c_str()));
						}
					}

					line_counter++;
				}
				myfile.close();
			}
			else {
				cout << "Unable to open file " << file_path << "...";
			}
		}		

		//The recharge thread
		SC_THREAD(thread_process); 
	}


private:
	unsigned int MAX_ENERGY;
	unsigned int RECHARGE;
	unsigned int DISCHARGE;
	int battery_level; 						// the level of the battery
	int battery_energy;						// the power available from the battery
	int battery_state; 						// the state of the battery. [0 = NOT RECHARGING | 1 = RECHARGING
	int energy_model_interval[255];
	double energy_model_coeff[255];
	int energy_model_entry_number;


	vector<string> my_split(string src, char delim)
	{	
		vector<string> result;
		string::size_type startPos = 0, endPos = 0;
		do
		{
			endPos = src.find_first_of(delim,startPos);
			string::size_type length = endPos - startPos;
			if(length != 0)
				result.push_back( src.substr(startPos,length) );
			startPos = endPos + 1;
		}
		while(endPos != string::npos);
		
		return result;
	}

	// The function definition of the Battery behaviour.
	// It allows easy change of the Battery Type (e.g. a non constant energy request)
 	// Can be based also on the instant of simulation
	int battery_behaviour_recharge(int instant = 0) 
	{
		return (int)RECHARGE; //for now implements constant request
		//return 50;
	}

	int battery_behaviour_discharge(int instant = 0) 
	{
		return (int)DISCHARGE; //for now implements constant request
		//return -100;
	}

	double apply_correction_factor(int watt_request)
	{

		double last_coeff = energy_model_coeff[0];
		
		for (int i = 0; i < energy_model_entry_number; i++){

			if (watt_request > energy_model_interval[i])
				return watt_request*last_coeff;

			last_coeff = energy_model_coeff[i];
		}

		/*
			if ((watt_request > 0	) && (watt_request < 50	))	return watt_request * 1.297;
			if ((watt_request > 50	) && (watt_request < 100))	return watt_request * 1.083;
			if ((watt_request > 100	) && (watt_request < 200))	return watt_request * 1.007;
			if ((watt_request > 200	) && (watt_request < 300))	return watt_request * 1.000;
			if ((watt_request > 300	) && (watt_request < 400))	return watt_request * 1.014;
			if ((watt_request > 400	) && (watt_request < 500))	return watt_request * 1.029;
			if ((watt_request > 500	) && (watt_request < 600))	return watt_request * 1.043;
			if ((watt_request > 600	) && (watt_request < 700))	return watt_request * 1.083;
			if ((watt_request > 700	) && (watt_request < 800))	return watt_request * 1.091;
			if ((watt_request > 800	) && (watt_request < 900))	return watt_request * 1.143;
			if ((watt_request > 900	) && (watt_request < 1000))	return watt_request * 1.152;
			if ((watt_request > 1000) && (watt_request < 1200))	return watt_request * 1.200;
			if ((watt_request > 1200) && (watt_request < 1400))	return watt_request * 1.286;
			if ((watt_request > 1400) && (watt_request < 1600))	return watt_request * 1.385;
			if ((watt_request > 1600) && (watt_request < 1800))	return watt_request * 1.455;
		*/

		SC_REPORT_ERROR("TLM-2", "Battery :: Energy request not satisfiable. Battery broken!");			
		return -1;

	}
	
	

	// The recharging thread process
	//battery_state = 0 -> STOP RECHARGING/DISCHARGING , battery_state = 1 -> RECHARGE , battery_state = 2 -> DISCHARGE
	void thread_process()
	{

		tlm::tlm_generic_payload *transaction = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(1, SC_NS);

		for(int i=START; i < END; i++)
		{

			if(battery_state == 1) // RECHARGE
			{
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "RECHARGING" << "\n";
				//cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_STATE" << " :: {" << battery_state << "}\n";
				int data = battery_behaviour_recharge(i);				
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "CURRENT_REQUEST" << " :: {" << data << "}"  << "\n";   		
			
				transaction->set_command(tlm::TLM_WRITE_COMMAND);
				transaction->set_address(ID_BATTERY + 101);
				transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&data));
				transaction->set_data_length(4);
				transaction->set_streaming_width(4); // = data_length to indicate no streaming
				transaction->set_byte_enable_ptr(0); // 0 indicates unused
				transaction->set_dmi_allowed(false); // Mandatory initial value
				transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				recharge_socket->b_transport(*transaction, delay);  // Blocking transport call

				if (transaction->is_response_error())
					SC_REPORT_ERROR("TLM-2", "Response error from b_transport");
				
				battery_energy += data; //Is the actual recharge instruction!
				battery_level = (100*battery_energy)/MAX_ENERGY; //Updates the level

				// Perform a check: if the current charge is more than 100, battery is then fully charged.
				// set battery level to 100 and stops charging
				if(battery_energy > MAX_ENERGY)
				{
					battery_level = 100;
					battery_energy = MAX_ENERGY;
					battery_state = 0;
				}
			}


			if(battery_state == 2) //DISCHARGE
			{
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "DISCHARGING" << "\n";
				//cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_STATE" << " :: {" << battery_state << "}\n";
				int data = battery_behaviour_discharge(i);
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "CURRENT_OUTPUT" << " :: {" << data << "}"  << "\n";   		
			
				transaction->set_command(tlm::TLM_WRITE_COMMAND);
				transaction->set_address(ID_BATTERY + 102);
				transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&data)); //send to powergenerator -(data) simulating the input of energy
				transaction->set_data_length(4);
				transaction->set_streaming_width(4); // = data_length to indicate no streaming
				transaction->set_byte_enable_ptr(0); // 0 indicates unused
				transaction->set_dmi_allowed(false); // Mandatory initial value
				transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				discharge_socket->b_transport(*transaction, delay);  // Blocking transport call

				if (transaction->is_response_error())
					SC_REPORT_ERROR("TLM-2", "Response error from b_transport");
				
				battery_energy += data; //Is the actual recharge instruction!
				battery_level = (100*battery_energy)/MAX_ENERGY; //Updates the level

				// Perform a check: if the current battery energy is equal to 20 
				// set battery level to 20% and stops charging

				/*if(battery_energy == 10)   //SET TO 10 ONLY FOR TRIALS
				{
					battery_level = 20;
					battery_energy = MAX_ENERGY;
					battery_state = 0;
				}
				*/
			}

			// if the current simulation is ending, let us save the current battery status
			if (i == END-START-1)
			{
				
				string file_name = "battery_status_";
				string file_path = "./Flowfiles/";
			
				char ID_BATTERY_STR[5];
				sprintf(ID_BATTERY_STR, "%d", ID_BATTERY);
				file_name.append(ID_BATTERY_STR);
				file_name.append(".csv");
				file_path.append(file_name);
				ofstream myfile;
				myfile.open(file_path.c_str());
				myfile << battery_energy << ";" << battery_level << ";" << battery_state << ";" << MAX_ENERGY << ";" << RECHARGE << ";" << DISCHARGE <<";";
				myfile.close();		
			}



			wait(delay);
		}
	}

//reply to CPU request of battery level
	virtual void CPU_b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");		

		if(cmd==tlm::TLM_READ_COMMAND)
		{
			if(adr == 0)
			{
				memcpy(ptr, &battery_level, len);   
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_LEVEL" << " :: {" << battery_level << "}\n";	
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_ENERGY" << " :: {" << battery_energy << "}\n";
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_STATE" << " :: {" << battery_state << "}\n";
			}
			
		}

		if (cmd == tlm::TLM_WRITE_COMMAND) 
		{
			int state;
			memcpy(&state, ptr, len); 	//the new value 
			if(battery_state != state) 	//changing state and doing output only if it is ACTUALLY a change state request
			{
				battery_state = state;
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "CHANGE_BATTERY STATE"  << " :: battery_state {" << battery_state << "}\n";
			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_STATE" << " :: {" << battery_state << "}\n";
			}
		}	

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);	
	}

	
};
