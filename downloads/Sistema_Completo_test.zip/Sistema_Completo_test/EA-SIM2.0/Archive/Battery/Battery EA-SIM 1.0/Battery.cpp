#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

#include <vector>

#define THREAD_ITERATIONS 1680

template<unsigned int NUMBER_OF_APPLIANCES , unsigned int ID_BATTERY, unsigned int CAPACITY, unsigned int RECHARGE >
class Battery : public sc_module
{
public:
	// TLM-2 socket, defaults to 32-bits wide, base protocol
	tlm_utils::simple_target_socket_tagged<Battery> *appliance_socket[NUMBER_OF_APPLIANCES]; 				// where it will send energy
	tlm_utils::simple_target_socket<Battery> cpu_socket;													// the cpu communication port
	tlm_utils::simple_initiator_socket<Battery> recharge_socket;											// from where it takes energy to recharge

	SC_CTOR(Battery) : cpu_socket("cpu_socket"), recharge_socket("recharge_socket")
	{
		// Register callback for incoming b_transport interface method call
		cpu_socket.register_b_transport(this, &Battery::CPU_b_transport);

		for(unsigned int i = 0; i < NUMBER_OF_APPLIANCES; i++)
		{
			char name[25];
			sprintf(name, "appliance_socket[%d]", i);
			appliance_socket[i] = new tlm_utils::simple_target_socket_tagged<Battery>(name);
			appliance_socket[i]->register_b_transport(this, &Battery::b_transport, i);
		}
		
		//Initialize both state and charge level
		battery_level = 100; // initialized as fully charged
		battery_state = 0;
		battery_power = CAPACITY; // initialized as fully charged
		attached_appliances = new std::vector<int>();

		//The recharge thread
		SC_THREAD(thread_process); 
	}


private:
	int battery_level; 						// the level of the battery
	int battery_power;						// the power available from the battery
	int battery_state; 						// the state of the battery. [0 = NOT RECHARGING | 1 = RECHARGING
	std::vector<int> *attached_appliances; 	// the the vector containing the discovered attached appliances

	// The function definition of the Battery behaviour.
	// It allows easy change of the Battery Type (e.g. a non constant energy request)
 	// Can be based also on the instant of simulation
	int battery_behaviour(int instant = 0) 
	{
		return RECHARGE; //for now implements constant request
	}
	
	// The recharging thread process
	void thread_process()
	{
		tlm::tlm_generic_payload *transaction = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(10, SC_NS);

		for(int i=0; i < THREAD_ITERATIONS; i++)
		{
			if(battery_state == 1) // RECHARGE
			{
				cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "RECHARGING" << "\n";
				int data = battery_behaviour();				
				cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "CURRENT_REQUEST" << " :: {" << data << "}"  << "\n";   		
			
				transaction->set_command(tlm::TLM_WRITE_COMMAND);
				transaction->set_address(ID_BATTERY + 100);
				transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&data));
				transaction->set_data_length(4);
				transaction->set_streaming_width(4); // = data_length to indicate no streaming
				transaction->set_byte_enable_ptr(0); // 0 indicates unused
				transaction->set_dmi_allowed(false); // Mandatory initial value
				transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				recharge_socket->b_transport(*transaction, delay);  // Blocking transport call

				if (transaction->is_response_error())
					SC_REPORT_ERROR("TLM-2", "Response error from b_transport");
				
				battery_power += data; //Is the actual recharge instruction!
				battery_level = (100*battery_power)/CAPACITY; //Updates the level

				// Perform a check: if the current charge is more than 100, battery is then fully charged.
				// set battery level to 100 and stops charging
				if(battery_power > CAPACITY)
				{
					battery_level = 100;
					battery_power = CAPACITY;
					battery_state = 0;
				}
			}
			else
				cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "NOT_RECHARGING" << "\n";


			wait(delay);
		}
	}

	virtual void CPU_b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");		

		if(cmd==tlm::TLM_READ_COMMAND)
		{
			if(adr == 0)
			{
				memcpy(ptr, &battery_level, len);   
				cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_LEVEL_RESPONSE" << " :: {" << battery_level << "}\n";	
			}
			if(adr == 1)
				memcpy(ptr, &attached_appliances, len); 
		}
		if (cmd == tlm::TLM_WRITE_COMMAND) 
		{
			int state;
			memcpy(&state, ptr, len); 	//the new value 
			if(battery_state != state) 	//changing state and doing output only if it is ACTUALLY a change state request
			{
				battery_state = state;
				cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "CHANGE_BATTERY STATE"  << " :: battery_state {" << battery_state << "}\n";
			}
		}	

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);	
	}

	// It decodes energy requests and update the battery level
	virtual void b_transport(int id, tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address(); //contains the ID_APPLIANCE of the appliance requesting energy
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");

		if(cmd == tlm::TLM_WRITE_COMMAND)
		{
			//if the appliance id sent is already present in the vector, the battery is already aware of this link
			//otherwise update the vector with this new discovery
			bool found = false;
			for(std::vector<int>::iterator it = attached_appliances->begin() ; it != attached_appliances->end(); ++it)
				if(*it == adr)
					found = true;
			if(!found)
				attached_appliances->push_back(adr);

			int current_request_value;
			memcpy(&current_request_value,ptr,len);
			battery_power -= current_request_value; //Is the actual discharging instruction!
			battery_level = (100*battery_power)/CAPACITY; //Updates the level

			cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "ENERGY_REQUEST_RESPONSE" << ":: " << battery_power << "\n";
			cout << sc_time_stamp() << " :: " << "Battery[" << ID_BATTERY << "]" << " :: " << "BATTERY_LEVEL" << ":: " << battery_level << "\n";
			
			if (battery_power < 0)
				SC_REPORT_ERROR("TLM-2", "Battery :: Battery value is minor then 0. Battery broken!");			
		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);	
	}
};
