#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"


template<unsigned int ID_BATTERY,unsigned int START,unsigned int END>
class CPU_Battery : public sc_module
{
public:
	// TLM-2 socket, defaults to 32-bits wide, base protocol
	tlm_utils::simple_target_socket<CPU_Battery> energy_box_socket;
	tlm_utils::simple_initiator_socket<CPU_Battery> battery_socket;
	
	SC_CTOR(CPU_Battery) : energy_box_socket("energy_box_socket"), battery_socket("battery_socket")
	{
		// Register callback for incoming b_transport interface method call	
		energy_box_socket.register_b_transport(this, &CPU_Battery::CPU_b_transport);

		battery_state = 0;
		battery_level = 100; //Initialized to fully charged

		//The thread which handles the recharging policies
		SC_THREAD(thread_process); 
	}
	
private:
	int battery_level;
	int battery_state;	// the state of the battery. [0 = NOT RECHARGING | 1 = RECHARGING | 2 = DISCHARGING]


	void thread_process()
	{
		tlm::tlm_generic_payload *transaction = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(1, SC_NS);

		for(int i=START; i < END; i++)
		{
			
			//Read the battery level
			transaction->set_command(tlm::TLM_READ_COMMAND);
			transaction->set_address(0); // battery_level request command convention
			transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&battery_level));
			transaction->set_data_length(4);
			transaction->set_streaming_width(4); // = data_length to indicate no streaming
			transaction->set_byte_enable_ptr(0); // 0 indicates unused
			transaction->set_dmi_allowed(false); // Mandatory initial value
			transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

			battery_socket->b_transport(*transaction, delay);  // Blocking transport call

			// Initiator obliged to check response status and delay
			if (transaction->is_response_error())
				SC_REPORT_ERROR("TLM-2", "Response error from b_transport");						




			// selecting battery state configuaration based on the battery level read before
			if(battery_level < 10)
				battery_state = 1; // rechanring
			/*else if(battery_level > 80)
				battery_state = 0; // stop recharge
			*/
			

			//Send the battery state configuration to battery
	//		cout << "$EASIM> " << sc_time_stamp() << " :: " << "CPU_Battery :: SENDING COMMAND TO BATTERY :: {" << battery_state << "} \n";
			transaction->set_command(tlm::TLM_WRITE_COMMAND);
			transaction->set_address(32);
			transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&battery_state));
			transaction->set_data_length(4);
			transaction->set_streaming_width(4); // = data_length to indicate no streaming
			transaction->set_byte_enable_ptr(0); // 0 indicates unused
			transaction->set_dmi_allowed(false); // Mandatory initial value
			transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

			battery_socket->b_transport(*transaction, delay);  // Blocking transport call

			if (transaction->is_response_error())
				SC_REPORT_ERROR("TLM-2", "Response error from b_transport");

			wait(delay);	
		}
	}

	//READ -> respond to energy box with  battery level (adr = 1) or battery state (adr = 0)
	//WRITE-> force recharge if the battery is not already fully charged. it communicate also over "data" the state of the battery
	virtual void CPU_b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay) 
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");	
	
		if(cmd==tlm::TLM_READ_COMMAND)
		{
			if (adr == 0)  //respond to energybox with battery state
			{  
				memcpy(ptr, &battery_state, len);   
		//		cout << "$EASIM> " << sc_time_stamp() << " :: " << "CPU_Battery{Battery[" << ID_BATTERY << "]} :: " << "BATTERY_STATE" << " :: {" << battery_state << "} \n";
			}	
			if (adr == 1) //respond to enerybox with battery lvl
			{
				memcpy(ptr, &battery_level, len);   
		//		cout << "$EASIM> " << sc_time_stamp() << " :: " << "CPU_Battery{Battery[" << ID_BATTERY << "]} :: "<< "BATTERY_LEVEL" << " :: {" << battery_level << "} \n";
			}
			if (adr == 2) 
			{
				transaction.set_address(1); //forwarding to battery the request to get attached_appliance vector pointer
				battery_socket->b_transport(transaction, delay);
			}

		}
		
		if(cmd==tlm::TLM_WRITE_COMMAND) //Force recharge request done by energy_box
		{

		//	cout << "$EASIM> " << sc_time_stamp() << " :: "  << "CPU_Battery{Battery[" << ID_BATTERY << "]} :: " << battery_state << " \n";
			if(battery_level < 100 && adr ==0) // if is 100 battery is fully charged nothing will be done, otherwise force recharge
			{
				memcpy(&battery_state, ptr, len);
				battery_socket->b_transport(transaction, delay);

			}else if(adr ==1){  //force battery to descharge 

				memcpy(&battery_state, ptr, len);
				battery_socket->b_transport(transaction, delay);
			}


		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);	
	}	
};
