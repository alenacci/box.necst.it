#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;
#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include "iostream"


template<unsigned int ID_APPLIANCE, unsigned int START, unsigned int END>
class ApplianceTelevision: public sc_module
{
public:
	tlm_utils::simple_initiator_socket<ApplianceTelevision> socket;

	SC_CTOR(ApplianceTelevision) : socket("socket")
	{
		SC_THREAD(thread_process);
	}


private:

	int pt_current_index;
	int pt_last_index;
	int power_trace[END];
	int app_initialized;
	int app_activated;
	bool elastic;


		vector<string> my_split(string src, char delim)
	{
		vector<string> result;
		string::size_type startPos = 0, endPos = 0;
		do
		{
			endPos = src.find_first_of(delim,startPos);
			string::size_type length = endPos - startPos;
			if(length != 0)
				result.push_back( src.substr(startPos,length) );
			startPos = endPos + 1;
		}
		while(endPos != string::npos);
		return result;
	}

	 void init_app()
	{
		app_activated = 0;
			if (app_initialized)
				return;

		app_initialized = 1;

	cout << "Loading appliance ID " << ID_APPLIANCE << " power trace...\n ";
	string line;
	string file_path = "./Archive/Flowfiles/Television.csv";
	ifstream myfile (file_path.c_str());
	int line_counter = 0;
	if (myfile.is_open())
		{
			while ( getline (myfile,line) )
			{
			if (line[0] == '#') continue;
			if (line_counter == END-1) break;
			std::vector<std::string> current_line;
			current_line = my_split(line, ';');
			power_trace[line_counter] = atoi(current_line[0].c_str());
			line_counter++;
			}
		myfile.close();
		pt_last_index = line_counter-1;

	}
	else cout << "Unable to open file " << file_path << "...";

	for(int i=line_counter; i < END; i++){
		 power_trace[i]=0;
	}

	}

