#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

template<unsigned int ID_APPLIANCE>
class PowerSwitch : public sc_module
{
public:
	// TLM-2 socket, defaults to 32-bits wide, base protocol
	tlm_utils::simple_target_socket<PowerSwitch> appliance_socket;
	tlm_utils::simple_target_socket<PowerSwitch> CPU_socket;

	tlm_utils::simple_initiator_socket<PowerSwitch> powergenerator_socket;

	SC_CTOR(PowerSwitch) : appliance_socket("appliance_socket"), CPU_socket("CPU_socket"), powergenerator_socket("powergenerator_socket")
	{
		appliance_socket.register_b_transport(this, &PowerSwitch::b_transport);
		CPU_socket.register_b_transport(this, &PowerSwitch::CPU_b_transport);

		appliance_consumption = 0;
		appliance_state = 0;
	}

private:
	int appliance_consumption;	// the consumption of the specific appliance
	int appliance_state; 		// the state of the appliance. [0 = USING POWER GENERATOR | 1 = USING BATTERY]

	virtual void CPU_b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");	

		if(cmd == tlm::TLM_READ_COMMAND)
		{
   			if(adr == 0)			// Appliance State Request
   				memcpy(ptr, &appliance_state, len);
   			if(adr == 1)			// Appliance Consumption Request
   				memcpy(ptr, &appliance_consumption, len); 
		}
		if(cmd == tlm::TLM_WRITE_COMMAND)
		{
			// A write cmd means a change in the state of the appliance
			// so it reads and save the value, if it is 0 then uses powergenerator_socket,
			// if it is 1 then uses battery, sending his own id with the request(see b_transport)
			memcpy(&appliance_state,ptr,len);
	//		cout << sc_time_stamp() << " :: " << "PowerSwitch{Appliance[" << ID_APPLIANCE << "]} :: POWER_STATE = " << appliance_state << "\n";
		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status( tlm::TLM_OK_RESPONSE );
	}

	virtual void b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();

		memcpy(&appliance_consumption, ptr, len); // Saves the energy request of the appliance

		// Deciding to which port send the request based on "appliance_state"
		if(appliance_state == 0)
		{
		//	cout << sc_time_stamp() << " :: " << "PowerSwitch{Appliance[" << ID_APPLIANCE << "]} :: FORWARDING_PWRQ to PowerGenerator\n";			
			powergenerator_socket->b_transport(transaction, delay);
		}
		if(appliance_state == 1)
		{
	//		cout << sc_time_stamp() << " :: " << "PowerSwitch{Appliance[" << ID_APPLIANCE << "]} :: FORWARDING_PWRQ to Battery\n";		
			
		}
	}

};
