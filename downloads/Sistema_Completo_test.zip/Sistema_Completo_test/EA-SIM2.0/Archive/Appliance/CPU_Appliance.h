#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

template<unsigned int ID_APPLIANCE>
class CPU_Appliance : public sc_module
{
public:
	// TLM-2 socket, defaults to 32-bits wide, base protocol
	tlm_utils::simple_target_socket<CPU_Appliance> energy_box_socket;
	tlm_utils::simple_initiator_socket<CPU_Appliance> powergenerator_socket;
	tlm_utils::simple_target_socket<CPU_Appliance> appliance_socket;

	SC_CTOR(CPU_Appliance) : appliance_socket("appliance_socket"), energy_box_socket("energy_box_socket"), powergenerator_socket("powergenerator_socket")
	{
		energy_box_socket.register_b_transport(this, &CPU_Appliance::CPU_b_transport);
		appliance_socket.register_b_transport(this, &CPU_Appliance::b_transport);
		appliance_consumption = 0;
		appliance_state = 0;
	}

private:
	int appliance_consumption;	// the consumption of the specific appliance
	int appliance_state; 		// the state of the appliance. [0 = USING POWER GENERATOR | 1 = USING BATTERY]
	
	//reply to energy_box requests
	virtual void CPU_b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if(byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");	

		if(cmd == tlm::TLM_READ_COMMAND)
		{
   			if(adr == 0)			// Appliance State Request
   				memcpy(ptr, &appliance_state, len);
   			if(adr == 1)			// Appliance Consumption Request
   				memcpy(ptr, &appliance_consumption, len); 
		}
		
		// Obliged to set response status to indicate successful completion
		transaction.set_response_status( tlm::TLM_OK_RESPONSE );
	}

    //send appliance request to power generator
	virtual void b_transport(tlm::tlm_generic_payload &transaction, sc_time &delay)
	{
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();

		memcpy(&appliance_consumption, ptr, len); // Saves the energy request of the appliance

		// Deciding to which port send the request based on "appliance_state"
		if(appliance_state == 0)
		{
		//	cout << "$EASIM> "<< sc_time_stamp() << " :: " << "CPU_Appliance{Appliance[" << ID_APPLIANCE << "]} :: FORWARDING_PWRQ to PowerGenerator\n";			
			powergenerator_socket->b_transport(transaction, delay);
		}
		
	}





};
