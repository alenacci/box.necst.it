#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;
#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include "iostream"


template<unsigned int ID_APPLIANCE, unsigned int START, unsigned int END>
class ApplianceElectric_Oven: public sc_module
{
public:
	tlm_utils::simple_initiator_socket<ApplianceElectric_Oven> socket;

	SC_CTOR(ApplianceElectric_Oven) : socket("socket")
	{
		SC_THREAD(thread_process);
	}


private:

	int pt_current_index;
	int pt_last_index;
	int power_trace[END];
	int app_initialized;
	int app_activated;
	bool elastic;


		vector<string> my_split(string src, char delim)
	{
		vector<string> result;
		string::size_type startPos = 0, endPos = 0;
		do
		{
			endPos = src.find_first_of(delim,startPos);
			string::size_type length = endPos - startPos;
			if(length != 0)
				result.push_back( src.substr(startPos,length) );
			startPos = endPos + 1;
		}
		while(endPos != string::npos);
		return result;
	}

	 void init_app()
	{
		app_activated = 0;
			if (app_initialized)
				return;

		app_initialized = 1;

	cout << "Loading appliance ID " << ID_APPLIANCE << " power trace...\n ";
	string line;
	string file_path = "./Archive/Flowfiles/Electric_Oven.csv";
	ifstream myfile (file_path.c_str());
	int line_counter = 0;
	if (myfile.is_open())
		{
			while ( getline (myfile,line) )
			{
			if (line[0] == '#') continue;
			if (line_counter == END-1) break;
			std::vector<std::string> current_line;
			current_line = my_split(line, ';');
			power_trace[line_counter] = atoi(current_line[0].c_str());
			line_counter++;
			}
		myfile.close();
		pt_last_index = line_counter-1;

	}
	else cout << "Unable to open file " << file_path << "...";

	for(int i=line_counter; i < END; i++){
		 power_trace[i]=0;
	}

	}

	int appliance_behaviour(int instant)
	{

		if( (instant % 86400) >= (68400) && (instant % 86400)<= (72000) )
		{
			return power_trace[((instant % 86400) - (68400)) ] ;
		}
		return 0;
	}

	void thread_process()
	{
		init_app();
		tlm::tlm_generic_payload *transaction = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(1, SC_NS);

		for(int i = START; i < END; i++)
		{

			int data = appliance_behaviour(i);
			sc_time delay = sc_time(1, SC_NS);


			transaction->set_command(tlm::TLM_WRITE_COMMAND);
			transaction->set_address(ID_APPLIANCE);
			transaction->set_data_ptr(reinterpret_cast<unsigned char*>(&data));
			transaction->set_data_length(4);
			transaction->set_streaming_width(4); // = data_length to indicate no streaming
			transaction->set_byte_enable_ptr(0); // 0 indicates unused
			transaction->set_dmi_allowed(false); // Mandatory initial value
			transaction->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

			socket->b_transport(*transaction, delay);  // Blocking transport call

			// Initiator obliged to check response status and delay
			if (transaction->is_response_error())
				SC_REPORT_ERROR("TLM-2", "Response error from b_transport");

			wait(delay);
		}
	}
};
