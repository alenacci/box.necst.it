#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

//#define THREAD_ITERATIONS 86400  //seconds in a day   
#define THREAD_ITERATIONS 7200  //seconds in a day   
template<unsigned int N_APPLIANCE, unsigned int M_BATTERY>
class PowerGenerator: public sc_module {
public:

	// TLM-2 socket, defaults to 32-bits wide, base protocol 
	tlm_utils::simple_target_socket<PowerGenerator> energy_box_socket;
	tlm_utils::simple_target_socket_tagged<PowerGenerator> *en_req_socket[N_APPLIANCE
	                                                                      + M_BATTERY];

	SC_CTOR(PowerGenerator): energy_box_socket("energy_box_socket")
	{
		energy_box_socket.register_b_transport(this, &PowerGenerator::CPU_b_transport);

                cout << "[PowerGenerator] - PreFor.\n";
		for (unsigned int i = 0; i < N_APPLIANCE + M_BATTERY; i++)//registers the N_APPLIANCES(powerswitch) + M_BATTERIES(recharge)
		{
			char name[20];
			sprintf(name, "socket_%d", i);
			en_req_socket[i]= new tlm_utils::simple_target_socket_tagged<PowerGenerator>(name);
			en_req_socket[i]->register_b_transport(this, &PowerGenerator::b_transport, i);

			for(unsigned int j = 0; j < THREAD_ITERATIONS; j++)
				current_consumption[i][j] = 0;
		}
                cout << "[PowerGenerator] - PostFor.\n";
		overall_consumption_total = 0;
		current_drain_total = 0;

		// Getting solar plants energy production information
		cout << "Loading SOLAR PLANT ENERGY DATA...\n";
		string line;
		ifstream myfile ("/home/easim/Scrivania/EA-SIM/ESE2/Archive/flowfiles/solar_plant.csv");
		int line_counter = 0;
                cout << "SOLAR PLANT Loaded.\n";
		if (myfile.is_open())
		{
			while ( getline (myfile,line) )
			{
				if (line[0] == '#') continue;
				if (line_counter == THREAD_ITERATIONS) break;
				std::vector<std::string> current_line;
				current_line = my_split(line, ';');
				max_current_solar[line_counter] = atoi(current_line[0].c_str());
				line_counter++;
			}
			myfile.close();
		}
		else cout << "Unable to open file PowerGenerator...";

		solar_enabled = 1;


	}

private:
	int current_consumption[N_APPLIANCE + M_BATTERY][THREAD_ITERATIONS];
	
	int overall_consumption_total;
	int current_drain_total;

	int overall_consumption_grid;
	int current_drain_grid;

	int overall_consumption_solar;
	int current_drain_solar;

	int solar_enabled;
	int max_current_solar[THREAD_ITERATIONS];

	vector<string> my_split(string src, char delim)
	{	
		vector<string> result;
		string::size_type startPos = 0, endPos = 0;
		do
		{
			endPos = src.find_first_of(delim,startPos);
			string::size_type length = endPos - startPos;
			if(length != 0)
				result.push_back( src.substr(startPos,length) );
			startPos = endPos + 1;
		}
		while(endPos != string::npos);
		
		return result;
	}

	int* compute_current_drains(int current_consumption_total[N_APPLIANCE + M_BATTERY][THREAD_ITERATIONS], int time_index, int* results)
	{

		results[0] = 0;
		results[1] = 0;
		results[2] = 0;

		int current_drain_total = 0;
		int current_drain_solar = 0;
		int current_drain_grid = 0;

                cout << "[PowerGenerator] - compute_current_drains IN.\n";
		if (solar_enabled) {
                        cout << "[PowerGenerator] - solar enabled.\n";
			for (unsigned int i = 0; i < N_APPLIANCE + M_BATTERY; i++){
				//cout << "$DEBUG> "  << sc_time_stamp() << " :: " <<  "r > pdf_gaussian " << "\n";
				current_drain_total += current_consumption_total[i][time_index];
				
				int next_drain_solar = current_drain_solar + current_consumption_total[i][time_index];

				if (next_drain_solar < max_current_solar[time_index])
				{
					current_drain_solar = next_drain_solar;
					//current_drain_total += 0;

				}
				else
				{
					int available_solar = max_current_solar[time_index] - current_drain_solar;
					current_drain_solar = max_current_solar[time_index];
					current_drain_grid += current_consumption_total[i][time_index] - available_solar;			
				}
			}
		
		} else {
			for (unsigned int i = 0; i < N_APPLIANCE + M_BATTERY; i++){
				current_drain_total += current_consumption_total[i][time_index];
				current_drain_solar = 0;
				current_drain_grid = current_drain_total;
			}
		}

		results[0] = current_drain_total;
		results[1] = current_drain_grid;
		results[2] = current_drain_solar;


	}

	virtual void b_transport(int id, tlm::tlm_generic_payload &transaction,
			sc_time &delay) {
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64 adr = transaction.get_address(); //will contains ID_APPLIANCE or ID_BATTERY
		unsigned char* ptr = transaction.get_data_ptr();
		unsigned int len = transaction.get_data_length();
		unsigned char* byt = transaction.get_byte_enable_ptr();
		unsigned int wid = transaction.get_streaming_width();

                cout << "[PowerGenerator] - b_transport.\n";
		if (byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2",
					"Target does not support given generic payload transaction");

		if (cmd == tlm::TLM_WRITE_COMMAND) {
			int curr_rq_val;
			memcpy(&curr_rq_val, ptr, len);

			int index = sc_time_stamp().value() / 1000;
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_INDEX" << " :: {" << index << "}\n";
			
			if (adr < 32000) {			
				if (adr >= 100) {
					current_consumption[adr - 100 + N_APPLIANCE][index] = curr_rq_val;
					cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "SOCKET{Battery[" << adr - 100 << "]} :: "<< "ENERGY_REQUEST_RESPONSE" << " :: {"<< current_consumption[adr - 100 + N_APPLIANCE][index]
							                                                << "}\n";
				} else {
					current_consumption[adr][index] = curr_rq_val;
					cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "<< "SOCKET{Appliance[" << adr << "]} :: "<< "ENERGY_REQUEST_RESPONSE" << " :: {"<< current_consumption[adr][index] << "}\n";
				}
			} else {
				if (adr == 32000){
					if (curr_rq_val > 0) solar_enabled = 1;
					else solar_enabled = 0;
				}
			}

			overall_consumption_total += curr_rq_val;

			int current_drains[3];
			compute_current_drains(current_consumption,index, current_drains);
			current_drain_total = current_drains[0];
			current_drain_grid = current_drains[1];
			current_drain_solar = current_drains[2];

			
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "MAX_CURRENT_SOLAR" << " :: {" << max_current_solar[index] << "}\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_TOTAL" << " :: {" << current_drain_total << "}\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_GRID" << " :: {" << current_drain_grid << "}\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_SOLAR" << " :: {" << current_drain_solar << "}\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "OVERALL_DRAIN" << " :: {" << overall_consumption_total<< "}\n";
		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);
	}

	// Responds to EnergyBox request (that are in fact only READ request) , adr = 0 -> overall consumption request , adr = 1 -> current drain request
	virtual void CPU_b_transport(tlm::tlm_generic_payload& transaction,	sc_time& delay) {
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64 adr = transaction.get_address();
		unsigned char* ptr = transaction.get_data_ptr();
		unsigned int len = transaction.get_data_length();
		unsigned char* byt = transaction.get_byte_enable_ptr();
		unsigned int wid = transaction.get_streaming_width();

                cout << "[PowerGenerator] - EnergyBox IN.\n";
		if (byt != 0 || len > 4 || wid < len)
			SC_REPORT_ERROR("TLM-2",
					"Target does not support given generic payload transaction");

		if (cmd == tlm::TLM_READ_COMMAND) {
			if (adr == 0) {
				memcpy(ptr, &overall_consumption_total, len);
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "<< "OVERALL CONSUMPTION" << " :: {"	<< overall_consumption_total << "}\n";
			}


			if (adr == 1) {
				int time_index = (sc_time_stamp().value() / 1000);

				int current_drains[3];
				compute_current_drains(current_consumption,time_index, current_drains);
				current_drain_total = current_drains[0];
				current_drain_grid = current_drains[1];
				current_drain_solar = current_drains[2];

				memcpy(ptr, &current_drain_total, len);
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_TOTAL" << " :: {" << current_drain_total << "}\n";
			}


			if (adr == 2) {
				int time_index = (sc_time_stamp().value() / 1000);

				int current_drains[3];
				compute_current_drains(current_consumption,time_index, current_drains);
				current_drain_total = current_drains[0];
				current_drain_grid = current_drains[1];
				current_drain_solar = current_drains[2];

				memcpy(ptr, &current_drain_grid, len);
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_GRID" << " :: {" << current_drain_grid << "}\n";
			}


			if (adr == 3) {
				int time_index = (sc_time_stamp().value() / 1000);

				int current_drains[3];
				compute_current_drains(current_consumption,time_index, current_drains);
				current_drain_total = current_drains[0];
				current_drain_grid = current_drains[1];
				current_drain_solar = current_drains[2];

				memcpy(ptr, &current_drain_solar, len);
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "CURRENT_DRAIN_SOLAR" << " :: {" << current_drain_solar << "}\n";
			}	


			if (adr == 4) {
				int time_index = (sc_time_stamp().value() / 1000);

				int max_current_solar_int = max_current_solar[time_index];
				
				memcpy(ptr, &max_current_solar_int, len);
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "PowerGenerator" << " :: "	<< "MAX_CURRENT_SOLAR" << " :: {" << max_current_solar_int << "}\n";
			}	

		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status(tlm::TLM_OK_RESPONSE);
	}
};

