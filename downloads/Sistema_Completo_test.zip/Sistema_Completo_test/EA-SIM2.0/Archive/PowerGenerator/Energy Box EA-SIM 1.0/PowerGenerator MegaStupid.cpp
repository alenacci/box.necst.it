//TO USE IN AN ARCHITECTURE WITH ONLY APPLIANCES AND ENERGYBOX
#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"

template <unsigned int N_APPLIANCE , unsigned int M_BATTERY>  
class PowerGenerator : public sc_module
{
public:
	enum{ SIZE = 1680 };

	// TLM-2 socket, defaults to 32-bits wide, base protocol 
	tlm_utils::simple_target_socket_tagged<PowerGenerator> *en_req_socket[N_APPLIANCE + M_BATTERY];
	
	SC_CTOR(PowerGenerator)  
	{

		for (unsigned int i = 0; i < N_APPLIANCE + M_BATTERY; i++)	//registers the N_APPLIANCES(powerswitch) + M_BATTERIES(recharge)
		{   
			char name[20];
			sprintf(name, "socket_%d", i);
			en_req_socket[i]= new tlm_utils::simple_target_socket_tagged<PowerGenerator>(name);
			en_req_socket[i]->register_b_transport(this, &PowerGenerator::b_transport, i);

			for(unsigned int j = 0; j < SIZE; j++)
				current_consumption[i][j] = 0;
		}
		overall_consumption = 0;
		current_drain = 0;
	}

private:
	int overall_consumption;
	int current_consumption[N_APPLIANCE + M_BATTERY][SIZE];
	int current_drain;

	virtual void b_transport(int id, tlm::tlm_generic_payload &transaction, sc_time &delay) 
	{
		tlm::tlm_command cmd = transaction.get_command();
		sc_dt::uint64    adr = transaction.get_address();  //will contains ID_APPLIANCE or ID_BATTERY
		unsigned char*   ptr = transaction.get_data_ptr();
		unsigned int     len = transaction.get_data_length();
		unsigned char*   byt = transaction.get_byte_enable_ptr();
		unsigned int     wid = transaction.get_streaming_width();

		if (byt != 0 || len > 4 || wid < len)
		  SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");
         
		if ( cmd == tlm::TLM_WRITE_COMMAND )
		{
			int curr_rq_val;
			memcpy(&curr_rq_val, ptr, len);

			int index = sc_time_stamp().value() / 10000;
			cout << sc_time_stamp() << " :: " << "PowerGenerator" << " :: " << "CurrentIndex" << " :: " << index << "\n";

			if (adr >= 100)
			{
				current_consumption[adr -100 + N_APPLIANCE][index] = curr_rq_val;
				cout << sc_time_stamp() << " :: " << "PowerGenerator" << " :: " << "SOCKET{Battery[" << adr -100 << "]} :: " << "ENERGY_REQUEST_RESPONSE"  << " :: {" << current_consumption[adr -100 + N_APPLIANCE][index] << "}\n";
			}
			else
			{
				current_consumption[adr][index] = curr_rq_val;
				cout << sc_time_stamp() << " :: " << "PowerGenerator" << " :: " << "SOCKET{Appliance[" << adr << "]} :: " << "ENERGY_REQUEST_RESPONSE"  << " :: {" << current_consumption[adr][index] << "}\n";
			}
			overall_consumption += curr_rq_val;

			//Calculates current drain
			current_drain = 0 ;
			for(unsigned int i = 0; i < N_APPLIANCE + M_BATTERY; i++)
				current_drain += current_consumption[i][index];
				cout << sc_time_stamp() << " :: " << "PowerGenerator" << " :: " << "CURRENT_DRAIN" << " :: {" << current_drain << "}\n";
				cout << sc_time_stamp() << " :: " << "PowerGenerator" << " :: " << "OVERALL_DRAIN" << " :: {" << overall_consumption << "}\n";
		}

		// Obliged to set response status to indicate successful completion
		transaction.set_response_status( tlm::TLM_OK_RESPONSE );
	}
	

};
