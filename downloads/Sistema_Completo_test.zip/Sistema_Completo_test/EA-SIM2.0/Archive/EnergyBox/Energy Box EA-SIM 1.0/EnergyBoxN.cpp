#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include <vector>
#define THREAD_ITERATIONS 3360  //Number of iterations for one week 
#define F1 0.149356
#define F2 0.126556
#define F3 0.126556
//Set PowerThreshold to 20 
template<unsigned int N_BATTERY, unsigned int M_APPLIANCE,unsigned int POWER_TRESHOLD>
class EnergyBox: public sc_module {
public:

	int data; //1 = tell CPU_BATTERY to recharge battery , 0 = tell CPU_BATTERY to use power generator , -1 = tell to all battery to recharge (if they can)
	int pow_gen_overall; //contains the overall drain of power generator
	int pow_gen_current; //contains the current drain of power generator
	double instant_cost; //contains the instant cost
	
	int indexvec[M_APPLIANCE]; //utility vector 
	bool battery_critical_state[N_BATTERY]; //keep track of batteries critical state 
	int appliance_battery[M_APPLIANCE];  //keep track of the association appliance->battery
	std::vector<int>* batteryMap[N_BATTERY]; //keep track of the association battery->appliance

	tlm::tlm_command cpu_W_cmd;   //write command to cpu
	tlm::tlm_command cpu_R_cmd;  //read command to cpu
	tlm::tlm_command pow_gen_cmd;  //read command to power generator
	

	tlm_utils::simple_initiator_socket<EnergyBox> pow_gen_socket;   // initiator socket in order to get data from powergenerator
	tlm_utils::simple_initiator_socket<EnergyBox>* cpu_appliance_socket[M_APPLIANCE]; //vector of initiator socket to get data from all appliances
	tlm_utils::simple_initiator_socket<EnergyBox>* cpu_battery_socket[N_BATTERY]; //vector of initiator socket to get data from all batteries
    
	//initialize the battery and appliance map, the sockets and the utility vector
	SC_CTOR(EnergyBox) : pow_gen_socket("pow_gen_socket")     
	{

		for (unsigned int i = 0; i < N_BATTERY; i++) {
			char txt[20];
			sprintf(txt, "cpu_battery_socket_%d", i);
			cpu_battery_socket[i]= new tlm_utils::simple_initiator_socket<EnergyBox>(txt);
			batteryMap[i] = 0;
			battery_critical_state[i]=false;
		}
		for (unsigned int j = 0; j < M_APPLIANCE; j++) {
			char txt[20];
			sprintf(txt, "cpu_appliance_socket_%d", j);
			cpu_appliance_socket[j]= new tlm_utils::simple_initiator_socket<EnergyBox>(txt); //index distinti
			indexvec [j]=-1;
			appliance_battery[j]= -1;
		}

		data = 0;
		instant_cost=0;
		cpu_W_cmd = static_cast<tlm::tlm_command>(tlm::TLM_WRITE_COMMAND);
		cpu_R_cmd = static_cast<tlm::tlm_command>(tlm::TLM_READ_COMMAND);
		pow_gen_cmd = static_cast<tlm::tlm_command>(tlm::TLM_READ_COMMAND);
		SC_THREAD(thread_process);

	}

private:

	//get max from a vector and his index
	int getMax(int a[], int dim) {
		int* max = new int[2];
		max[0] = 0;
		for (int i = 0; i < dim; i++) {
			if (max[0] < a[i]) {
				max[0] = a[i];
				max[1] = i;
			}
		}
		return max[1];
	}
	//get max from a vector not considering for element j
	int* getMaxExclusive(int a[], int dim, int j) {
		int* max = new int[2];
		max[0] = 0;
		for (int i = 0; i < dim; i++) {
			if (i == j)
				continue;
			if (max[0] < a[i]) {
				max[0] = a[i];
				max[1] = i;
			}
		}
		return max;
	}
	//extract the maximum from a vector excluding all indexes in vector j
	inline int getMaxExclusiveVector(int a[], int dim, int j[]) {
		int* max = new int[2];
		int * c = new int[dim];
		int* d = new int[dim];
		for (int k = 0; k < dim; k++) {
			c[k] = a[k];
			d[k] = j[k];
		}
		max[0] = 0;
		for (int k = 0; k < dim; k++) {
			for (int i = 0; i < dim; i++) {
				if (d[i] != -1)
					c[d[i]] = 0;
			}
			if (max[0] < c[k]) {
				max[0] = c[k];
				max[1] = k;
			}

		}
		return max[1];
	}
	//resume values of the utility vector
	inline void resumeValues(int b[], int dim) {
		for (int i = 0; i < dim; i++) {
			b[i] = -1;
		}
	}


	void thread_process() {
		tlm::tlm_generic_payload* cpu_appliance_trans =	new tlm::tlm_generic_payload[M_APPLIANCE];
		tlm::tlm_generic_payload* cpu_battery_trans =new tlm::tlm_generic_payload[N_BATTERY];
		tlm::tlm_generic_payload* pow_gen_trans = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(5, SC_NS); //delay = 5 ut 

		int b_level;  //contains the battery level
		int b_state;  //contains the battery state (charging/not recharging)
		int a_status; //contains the appliance status(battery/powergenerator)
		int a_level;  //contains the appliance request
		int appliance_status[M_APPLIANCE];  //vector storing appliance status
		int appliance_level[M_APPLIANCE];  //vector storing appliance level
		int battery_level[N_BATTERY];   //vector storing battery level
		int battery_state[N_BATTERY]; //vector storing battery state

		for (int i = 0; i < THREAD_ITERATIONS; i++) {

			int the_addr = 32;

			//Announcing the eras

			if ((sc_time_stamp().value() / 1000) % 2400 == 0
					|| (sc_time_stamp().value() / 1000) % 2400 == 2000) {
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Danger!! we  are in the On-peak period " << "\n";
			}

			if ((sc_time_stamp().value() / 1000) % 2400 == 700
					|| (sc_time_stamp().value() / 1000) % 2400 == 1900) {
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Wellcome in the Mid-peak period " << "\n";
			}

			if ((sc_time_stamp().value() / 1000) % 2400 == 1100) {
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Wellcome in the Off-peak period " << "\n";
			}

			// ========================================== ENERGY BOX GATHERING DATA  ==========================================

			// 1 -GETTING POWER GENERATOR OVERALL DRAIN
			// ==============================================================================================================================
			//address = 1 => getting overall drain
			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(1);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_overall));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

			cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: OverallDrain {"<< pow_gen_overall << "}\n";

			// 2 -GETTING POWER GENERATOR CURRENT DRAIN
			// ==============================================================================================================================
			// address = 0 => getting current drain
			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(0);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_current));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

			cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: Current Drain {"<< pow_gen_current << "}\n";

			// 3- GET Battery Level from CPU_BATTERY
			// ==============================================================================================================================
			// address = 1 => get battery level
			for (int k = 0; k < N_BATTERY; k++) {
				cpu_battery_trans[k].set_command(cpu_R_cmd);
				cpu_battery_trans[k].set_address(1);
				cpu_battery_trans[k].set_data_ptr(
						reinterpret_cast<unsigned char*>(&b_level));
				cpu_battery_trans[k].set_data_length(4);
				cpu_battery_trans[k].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_battery_trans[k].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_battery_trans[k].set_dmi_allowed(false); // Mandatory initial value
				cpu_battery_trans[k].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_battery_socket[k])->b_transport(cpu_battery_trans[k],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_battery_trans[k].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Battery [" << k << "] Level =" << " :: " << b_level<< "\n";

				battery_level[k] = b_level;
			}

			// 4 - GET Battery State (Recharging/Not recharging) CPU_BATTERY_socket
			// ==============================================================================================================================
			// 0 = get battery state
			for (int k = 0; k < N_BATTERY; k++) {
				cpu_battery_trans[k].set_command(cpu_R_cmd);
				cpu_battery_trans[k].set_address(0);
				cpu_battery_trans[k].set_data_ptr(
						reinterpret_cast<unsigned char*>(&b_state));
				cpu_battery_trans[k].set_data_length(4);
				cpu_battery_trans[k].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_battery_trans[k].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_battery_trans[k].set_dmi_allowed(false); // Mandatory initial value
				cpu_battery_trans[k].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_battery_socket[k])->b_transport(cpu_battery_trans[k],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_battery_trans[k].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Battery [" << k << "] State =" << " :: " << b_state<< "\n";

				battery_state[k] = b_state;
			}

			// 5 - GET batteryMap, contains association between appliances and batteries
			// ==========================================

			for (int k = 0; k < N_BATTERY; k++) {

				if (batteryMap[k] != 0)
					continue;

				cpu_battery_trans[k].set_command(cpu_R_cmd);
				cpu_battery_trans[k].set_address(2);
				cpu_battery_trans[k].set_data_ptr(
						reinterpret_cast<unsigned char*>(&batteryMap[k]));
				cpu_battery_trans[k].set_data_length(4);
				cpu_battery_trans[k].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_battery_trans[k].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_battery_trans[k].set_dmi_allowed(false); // Mandatory initial value
				cpu_battery_trans[k].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_battery_socket[k])->b_transport(cpu_battery_trans[k],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_battery_trans[k].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

			}
			for (int k = 0; k < N_BATTERY; k++) {
				for (std::vector<int>::iterator it = batteryMap[k]->begin();
						it != batteryMap[k]->end(); ++it) {
					if (appliance_battery[*it] == -1)
						appliance_battery[*it] = k;
					cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Appliance_Battery [" << *it << "] =  " << k<< "\n";
				}
			}

			// 6 - GET APPLIANCE STATUS FROM CPU_APPLIANCE
			// STATUS 1 = usando batteria , STATUS 0  = usando pow_gen
			// ==========================================
			for (int j = 0; j < M_APPLIANCE; j++) {
				cpu_appliance_trans[j].set_command(cpu_R_cmd);
				cpu_appliance_trans[j].set_address(0);
				cpu_appliance_trans[j].set_data_ptr(
						reinterpret_cast<unsigned char*>(&a_status));
				cpu_appliance_trans[j].set_data_length(4);
				cpu_appliance_trans[j].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_appliance_trans[j].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_appliance_trans[j].set_dmi_allowed(false); // Mandatory initial value
				cpu_appliance_trans[j].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_appliance_socket[j])->b_transport(cpu_appliance_trans[j],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_appliance_trans[j].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Appliance [" << j << "] Status = " << ":: "<< a_status << "\n";

				appliance_status[j] = a_status;
			}

			// 7 - GET APPLIANCE LEVEL FROM CPU_APPLIANCE
			// ==========================================
			for (int j = 0; j < M_APPLIANCE; j++) {
				cpu_appliance_trans[j].set_command(cpu_R_cmd);
				cpu_appliance_trans[j].set_address(1);
				cpu_appliance_trans[j].set_data_ptr(
						reinterpret_cast<unsigned char*>(&a_level));
				cpu_appliance_trans[j].set_data_length(4);
				cpu_appliance_trans[j].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_appliance_trans[j].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_appliance_trans[j].set_dmi_allowed(false); // Mandatory initial value
				cpu_appliance_trans[j].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_appliance_socket[j])->b_transport(cpu_appliance_trans[j],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_appliance_trans[j].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Appliance[" << j << "] Level = " << ":: " << a_level<< "\n";

				appliance_level[j] = a_level;

			}

			// ========================================================================================================================================================================

			// ========================================== ENERGY BOX POLICIES  ==========================================
			/*I've define two time-of-use price periods (over 24h) :
			 1) Mid-peak period  --> when demand for electricity is medium   7:00 -8:00 and 19:00 - 23:00  (1900-2000) (700-1100)  (
			 2) Off-peak  --> when demand for electricity is low  23:00-7:00  (1100 - 1900)
			 2) On-peak (500-990) --> when demand for electricity is high  8:00 - 19:00   (0-700) (2000-2400)
			 based on this I've modeled three policies in orded to reduce the peak
			 */
			// =====================================================================  OFF-PEAK POLICIES  ===================================================================================================
			// POLICY DESCRIPTION : SEND ALL APPLIANCE TO POWER GENERATOR AND FORCE ALL BATTERY TO RECHARGE
			if ((sc_time_stamp().value() / 1000) % 2400 >= 1100	&& (sc_time_stamp().value() / 1000) % 2400 < 1900) {
				instant_cost = ((pow_gen_current * 10) * (F2 / 100000));
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "INSTANT COST" << " :: {" << instant_cost << "}"
						<< "\n";

				//SENDING TO ALL CPU_APPLIANCE COMMAND TO SWITCH TO POWERGENERATOR
				// data = 0  -> tell CPU_APPLIANCE to use power generator
				data = 0;
				for (int i = 0; i < M_APPLIANCE; i++) {
					if (appliance_status[i] != 0) {
						cpu_appliance_trans[i].set_command(cpu_W_cmd);
						cpu_appliance_trans[i].set_address(the_addr);
						cpu_appliance_trans[i].set_data_ptr(
								reinterpret_cast<unsigned char*>(&data));
						cpu_appliance_trans[i].set_data_length(4);
						cpu_appliance_trans[i].set_streaming_width(4); // = data_length to indicate no streaming
						cpu_appliance_trans[i].set_byte_enable_ptr(0); // 0 indicates unused
						cpu_appliance_trans[i].set_dmi_allowed(false); // Mandatory initial value
						cpu_appliance_trans[i].set_response_status(
								tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

						(*cpu_appliance_socket[i])->b_transport(
								(cpu_appliance_trans)[i], delay); // Blocking transport call

						// Initiator obliged to check response status and delay
						if (cpu_appliance_trans[i].is_response_error())
							SC_REPORT_ERROR("TLM-2",
									"Response error from b_transport");

						cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "OFF-PEAK PERIOD : "<< "Tell Appliance[" << i<< "] to use the Power Generator " << "\n";

					}
				}

				//SENDING TO ALL CPU_BATTERY TO RECHARGE BATTERY

				for (int i = 0; i < N_BATTERY; i++) {
					if (battery_state[i] == 0 && battery_level[i] < 60) { 
						cpu_battery_trans[i].set_command(cpu_W_cmd);
						cpu_battery_trans[i].set_address(1);
						cpu_battery_trans[i].set_data_ptr(
								reinterpret_cast<unsigned char*>(&data));
						cpu_battery_trans[i].set_data_length(4);
						cpu_battery_trans[i].set_streaming_width(4); // = data_length to indicate no streaming
						cpu_battery_trans[i].set_byte_enable_ptr(0); // 0 indicates unused
						cpu_battery_trans[i].set_dmi_allowed(false); // Mandatory initial value
						cpu_battery_trans[i].set_response_status(
								tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

						(*cpu_battery_socket[i])->b_transport(
								(cpu_battery_trans)[i], delay); // Blocking transport call

						// Initiator obliged to check response status and delay
						if (cpu_battery_trans[i].is_response_error())
							SC_REPORT_ERROR("TLM-2",
									"Response error from b_transport");
						
					    	cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "OFF-PEAK PERIOD : "<< "Forcing Battery[" << i	<< "] to recharge " << "\n";
						
					}
				}
			}

			// =====================================================================  ON-PEAK POLICIES  ===================================================================================================
			// POLICY DESCRIPTION : SEND ALL APPLIANCE TO BATTERY  AND FORCE ALL BATTERY TO STOP RECHARGE
			if (((sc_time_stamp().value() / 1000) % 2400 >= 0 && (sc_time_stamp().value() / 1000) % 2400 < 700) || ((sc_time_stamp().value() / 1000) % 2400 >= 2000 && (sc_time_stamp().value() / 1000) % 2400 < 2400)) {
				instant_cost = ((pow_gen_current * 10) * (F1 / 1000));
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "INSTANT COST" << " :: {" << instant_cost << "}"<< "\n";

				//SENDING TO ALL CPU_APPLIANCE COMMAND TO SWITCH TO BATTERY
				// data = 1  -> tell CPU_APPLIANCE to use battery
				data = 1;
				for (int i = 0; i < M_APPLIANCE; i++) {
					if (appliance_status[i] != 1
							&& !battery_critical_state[appliance_battery[i]]
							&& battery_state[appliance_battery[i]] == 0) {
						cpu_appliance_trans[i].set_command(cpu_W_cmd);
						cpu_appliance_trans[i].set_address(the_addr);
						cpu_appliance_trans[i].set_data_ptr(
								reinterpret_cast<unsigned char*>(&data));
						cpu_appliance_trans[i].set_data_length(4);
						cpu_appliance_trans[i].set_streaming_width(4); // = data_length to indicate no streaming
						cpu_appliance_trans[i].set_byte_enable_ptr(0); // 0 indicates unused
						cpu_appliance_trans[i].set_dmi_allowed(false); // Mandatory initial value
						cpu_appliance_trans[i].set_response_status(
								tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

						(*cpu_appliance_socket[i])->b_transport(
								(cpu_appliance_trans)[i], delay); // Blocking transport call

						// Initiator obliged to check response status and delay
						if (cpu_appliance_trans[i].is_response_error())
							SC_REPORT_ERROR("TLM-2",
									"Response error from b_transport");

						cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: " << "ON-PEAK PERIOD : "<< "Tell Appliance[" << i<< "] to use the his Battery  " << "\n";
					}
				}

				//SENDING TO ALL CPU_BATTERY TO STOP RECHARGING BATTERY
				for (int i = 0; i < N_BATTERY; i++) {
					if (battery_state[i] == 1 && !battery_critical_state[i]) {
						cpu_battery_trans[i].set_command(cpu_W_cmd);
						cpu_battery_trans[i].set_address(2);
						cpu_battery_trans[i].set_data_ptr(
								reinterpret_cast<unsigned char*>(&data));
						cpu_battery_trans[i].set_data_length(4);
						cpu_battery_trans[i].set_streaming_width(4); // = data_length to indicate no streaming
						cpu_battery_trans[i].set_byte_enable_ptr(0); // 0 indicates unused
						cpu_battery_trans[i].set_dmi_allowed(false); // Mandatory initial value
						cpu_battery_trans[i].set_response_status(
								tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

						(*cpu_battery_socket[i])->b_transport(
								(cpu_battery_trans)[i], delay); // Blocking transport call

						// Initiator obliged to check response status and delay
						if (cpu_battery_trans[i].is_response_error())
							SC_REPORT_ERROR("TLM-2",
									"Response error from b_transport");

						cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "ON-PEAK PERIOD : "<< "Forcing Battery[" << i<< "] to stop recharging" << "\n";
					}
				}
			}

			// =====================================================================  MID-PEAK POLICIES  ===================================================================================================
			// POLICY DESCRIPTION : IF CURRENT DRAIN OF POWER GENERATOR IS GREATER THAN A GIVEN TRESHOLD , FOUND THE MAX CONSUMING APPLIANCE AND FORCE IT TO USE BATTERY (IF HIS BATTERY IS NOT RECHARGING OR IN A CRITICAL STATE)

			if (((sc_time_stamp().value() / 1000) % 2400 >= 700	&& (sc_time_stamp().value() / 1000) % 2400 < 1100)|| ((sc_time_stamp().value() / 1000) % 2400 >= 1900 && (sc_time_stamp().value() / 1000) % 2400 <= 2000)) {

				instant_cost = (pow_gen_current * 10) * (F2 / 100000);
				cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "INSTANT COST" << " :: {" << instant_cost << "}"<< "\n";

				if (pow_gen_current >= 0 && pow_gen_current <= POWER_TRESHOLD) {
					cout << sc_time_stamp() << " :: " << "MID-PEAK PERIOD : "<< "EnergyBox save the day: power generator drain reduced "<< "\n";

				} else {
					cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "MID-PEAK PERIOD : "<< "Power Generator overloaded , try reducing consumption"	<< "\n";
					int indice;
					//LOOKING FOR THE MORE POWER DEMANDING APPLIANCES UNTIL POWER GENERATOR CURRENT CONSUMPTION IS BELOW THE TRESHOLD
					for (int i = 0; i < M_APPLIANCE; i++) {

						if (i == 0) {
							indice = getMax(appliance_level, M_APPLIANCE);
						} else {
							indice = getMaxExclusiveVector(appliance_level,
									M_APPLIANCE, indexvec); //get the appliance that is demanding more
						}
						indexvec[i] = indice;

						if (appliance_status[indice] == 0
								&& !battery_critical_state[appliance_battery[indice]]) {

							cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "MID-PEAK PERIOD : "<< "Found Appliance demanding more energy with id ="<< indice << "\n";
							data = 1;
							// SENDING TO CPU_APPLIANCE COMMAND TO SWITCH POWER SOURCE
							//data = 1 ->  tell CPU_APPLIANCE to  use battery , data = 0  -> tell CPU_APPLIANCE to use power generator
							// ==========================================
							cpu_appliance_trans[indice].set_command(cpu_W_cmd);
							cpu_appliance_trans[indice].set_address(the_addr);
							cpu_appliance_trans[indice].set_data_ptr(
									reinterpret_cast<unsigned char*>(&data));
							cpu_appliance_trans[indice].set_data_length(4);
							cpu_appliance_trans[indice].set_streaming_width(4); // = data_length to indicate no streaming
							cpu_appliance_trans[indice].set_byte_enable_ptr(0); // 0 indicates unused
							cpu_appliance_trans[indice].set_dmi_allowed(false); // Mandatory initial value
							cpu_appliance_trans[indice].set_response_status(
									tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

							(*cpu_appliance_socket[indice])->b_transport(
									(cpu_appliance_trans)[indice], delay); // Blocking transport call

							// Initiator obliged to check response status and delay
							if (cpu_appliance_trans[indice].is_response_error())
								SC_REPORT_ERROR("TLM-2",
										"Response error from b_transport");

							cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "MID-PEAK PERIOD : "<< "Tell Appliance[" << indice	<< "] to use his battery " << "\n";

							break;

						} else {
							if (battery_critical_state[appliance_battery[indice]]) {
								cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "MID-PEAK PERIOD : "<< "Battery["<< appliance_battery[indice]<< "] of  Appliance[" << indice<< "] is in critical state" << "\n";
								continue;
							}
							if (battery_state[appliance_battery[indice]] == 1) {
								cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "MID-PEAK PERIOD : "<< "Battery["<< appliance_battery[indice]<< "] of  Appliance[" << indice<< "] is recharging!!!! " << "\n";
								continue;
							}
							if (appliance_status[indice] == 1) {
								cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "MID-PEAK PERIOD : "<< "Appliance[" << indice<< "] is already using his battery "<< "\n";
								continue;
							}

						}
					}
				}
				resumeValues(indexvec, M_APPLIANCE);
			}

			// =====================================================================  END OF MID-PEAK POLICIES  ===================================================================================================

			//==================================================================  BATTERIES CRITICAL STATE CHECKING  ===================================================================================================

			//IF THERE IS A BATTERY WHO IS RECHARGING DUE TO HIS RESIDUAL CHARGE (DECISION MAKE BY CPU_BATTERY) ENERGYBOX HAVE TO UNPLUG THE APPLIANCES FROM THAT BATTERY
			//OTHERWISE THE BATTERY WILL BROKEN SOON

			for (int i = 0; i < N_BATTERY; i++) {
				if (battery_level[i] >= 33 && battery_state[i] == 0) {
					battery_critical_state[i] = false;
				}

				if (battery_state[i] == 1 || battery_level[i] < 33) {

					//EXTRACT ALL THE APPLIANCES ATTACHED TO THE BATTERY AND SENDING TO CPU_APPLIANCE COMMAND TO SWITCH POWER SOURCE
					//data = 0  -> tell CPU_APPLIANCE to use power generator
					for (std::vector<int>::iterator it = batteryMap[i]->begin();
							it != batteryMap[i]->end(); ++it) {

						if (appliance_status[*it] == 0)
							continue;

						data = 0;
						cpu_appliance_trans[*it].set_command(cpu_W_cmd);
						cpu_appliance_trans[*it].set_address(the_addr);
						cpu_appliance_trans[*it].set_data_ptr(
								reinterpret_cast<unsigned char*>(&data));
						cpu_appliance_trans[*it].set_data_length(4);
						cpu_appliance_trans[*it].set_streaming_width(4); // = data_length to indicate no streaming
						cpu_appliance_trans[*it].set_byte_enable_ptr(0); // 0 indicates unused
						cpu_appliance_trans[*it].set_dmi_allowed(false); // Mandatory initial value
						cpu_appliance_trans[*it].set_response_status(
								tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

						(*cpu_appliance_socket[*it])->b_transport(
								(cpu_appliance_trans)[*it], delay); // Blocking transport call

						// Initiator obliged to check response status and delay
						if (cpu_appliance_trans[*it].is_response_error())
							SC_REPORT_ERROR("TLM-2",
									"Response error from b_transport");

						cout << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "Tell Appliance[" << *it<< "] to use PowerGenerator , Battery[" << i<< "] is in critical state " << "\n";
						battery_critical_state[i] = true;

					}

				}

			}

			wait(delay);

		} //CLOSE OUTER FOR

		// ========================================================================================================================================================================

	} //CLOSE THREAD

};
