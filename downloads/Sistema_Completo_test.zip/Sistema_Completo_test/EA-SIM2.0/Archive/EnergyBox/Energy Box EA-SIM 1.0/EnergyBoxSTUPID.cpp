//TO USE IN AN ARCHITECTURE WITH ONLY APPLIANCES AND POWER GENERATOR 
#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include <vector>
#define THREAD_ITERATIONS 3360
#define F1 0.149356
#define F2 0.131296
#define F3 0.131296


template<unsigned int N_BATTERY, unsigned int M_APPLIANCE , unsigned int POWER_TRESHOLD>
class EnergyBox : public sc_module
{
public:

	double instant_cost;
	int pow_gen_current;
	tlm::tlm_command pow_gen_cmd;    	 
	tlm_utils::simple_initiator_socket<EnergyBox> pow_gen_socket ; 


	SC_CTOR(EnergyBox) : pow_gen_socket("pow_gen_socket")
	{

		pow_gen_cmd = static_cast<tlm::tlm_command>(tlm::TLM_READ_COMMAND);
		SC_THREAD(thread_process);     
		instant_cost =0;
		pow_gen_current =0;
	}   

private :


	void thread_process(){
		tlm::tlm_generic_payload* pow_gen_trans = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(5, SC_NS);





		for (int i = 0; i < THREAD_ITERATIONS; i++){

			// ========================================== ENERGY BOX GATHERING DATA  ========================================== 


			// 2 -GETTING POWER GENERATOR CURRENT DRAIN  
			// ==========================================  
			// address = 0 => getting current drain 
			pow_gen_trans->set_command(  pow_gen_cmd );
			pow_gen_trans->set_address( 0 );
			pow_gen_trans->set_data_ptr( reinterpret_cast<unsigned char*>(&pow_gen_current));
			pow_gen_trans->set_data_length( 4 );
			pow_gen_trans->set_streaming_width( 4 ); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr( 0 ); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed( false ); // Mandatory initial value
			pow_gen_trans->set_response_status( tlm::TLM_INCOMPLETE_RESPONSE ); // Mandatory initial value
			pow_gen_socket->b_transport( *pow_gen_trans, delay );  // Blocking transport call


			// Initiator obliged to check response status and delay
			if ( pow_gen_trans->is_response_error() )
				SC_REPORT_ERROR("TLM-2", "Powergenerator_transaction - Response error from b_transport");

			cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: " << "PowerGenerator" << " :: Current Drain {" << pow_gen_current << "}\n";






			// ========================================================================================================================================================================


			// ========================================== ENERGY BOX POLICIES  ========================================== 
			/*I've define two time-of-use price periods : 
       												1) Mid-peak period  --> when demand for electricity is medium   7:00 -8:00 and 19:00 - 23:00  (1900-2000) (700-1100)  (
       												2) Off-peak  --> when demand for electricity is low  23:00-7:00  (1100 - 1900) 
       												2) On-peak (500-990) --> when demand for electricity is high  8:00 - 19:00   (0-700) (2000-2400)
       	based on this I've modeled three policies in orded to reduce the peak 
			 */
			// =====================================================================  OFF-PEAK POLICIES  ===================================================================================================	   
			// POLICY DESCRIPTION : SEND ALL APPLIANCE TO POWER GENERATOR AND FORCE ALL BATTERY TO RECHARGE																
			if((sc_time_stamp().value()/1000)%2400  >=1100  && (sc_time_stamp().value()/1000)%2400  < 1900  )  { 	

				instant_cost= ((pow_gen_current*10) *(F2/100));
				cout << sc_time_stamp()<< " :: " << "EnergyBox" << " :: "  << "INSTANT COST" <<  " :: {"  << instant_cost << "}" << "\n";
			}

			// =====================================================================  ON-PEAK POLICIES  ===================================================================================================	   
			// POLICY DESCRIPTION : SEND ALL APPLIANCE TO BATTERY GENERATOR AND FORCE ALL BATTERY TO STOP RECHARGE																
			if( ((sc_time_stamp().value()/1000)%2400  >= 0 && (sc_time_stamp().value()/1000)%2400  < 700) || ( (sc_time_stamp().value()/1000)%2400  >= 2000  && (sc_time_stamp().value()/1000)%2400  < 2400) ){

				instant_cost= ((pow_gen_current*10)*(F1/100));  
				cout << sc_time_stamp()<< " :: " << "EnergyBox" << " :: "  << "INSTANT COST" <<  " :: {"  << instant_cost << "}" << "\n";

			}

			// =====================================================================  MID-PEAK POLICIES  ===================================================================================================	   
			// POLICY DESCRIPTION : IF CURRENT DRAIN OF POWER GENERATOR IS GREATER THAN A GIVEN TRESHOLD , FOUND THE MAX CONSUMING APPLIANCE AND FORCE IT TO USE BATTERY (IF HIS BATTERY IS NOT RECHARGING OR IN A CRITICAL STATE)														

			if( ( (sc_time_stamp().value()/1000)%2400 >= 700  && (sc_time_stamp().value()/1000)%2400 < 1100 ) || ( (sc_time_stamp().value()/1000)%2400 >= 1900 && (sc_time_stamp().value()/1000)%2400 <= 2000) ){ 

				instant_cost=  (pow_gen_current*10)*(F2/100);

				cout << sc_time_stamp()<< " :: " << "EnergyBox" << " :: "  << "INSTANT COST" <<  " :: {"  << instant_cost << "}" << "\n";

			}

			// =====================================================================  END OF MID-PEAK POLICIES  ===================================================================================================	   

			wait(delay);      
		}

	} //CLOSE OUTER FOR

	// ========================================================================================================================================================================

} ;//CLOSE THREAD 


