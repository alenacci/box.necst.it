#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include <vector>
#include "math.h"

#define F1 0.180000   //  €/kWh for the 'orange period'
#define F23 0.07000   //  €/kWh for the 'blu period'
#define c_factor 0.000277778 //conversion factor from kWs to kWh
//Set PowerThreshold to 20 
template<unsigned int N_BATTERY, unsigned int M_APPLIANCE,unsigned int START,unsigned int END, unsigned int THRESHOLD>
class EnergyBox: public sc_module {
public:
	int data; //1 = tell CPU_BATTERY to recharge battery , 0 = tell CPU_BATTERY to use power generator , -1 = tell to all battery to recharge (if they can)
	int pow_gen_overall; //contains the overall drain of power generator
	int pow_gen_current_total; //contains the current drain of power generator
	int pow_gen_current_grid; //contains the current drain of power generator
	int pow_gen_current_solar; //contains the current drain of power generator
	int pow_gen_max_current_solar; //contanins the maximum energy available form the solar plant in the current intant
	int pow_gen_current[END-START];
	bool fulfill;
	double cost_f1; //contains the instant cost for the F1 period
	double cost_f23; //contains the instant cost for the F23 period

	

	tlm::tlm_command cpu_W_cmd;   //write command to cpu
	tlm::tlm_command cpu_R_cmd;  //read command to cpu
	tlm::tlm_command pow_gen_cmd;  //read command to power generator
	

	tlm_utils::simple_initiator_socket<EnergyBox> pow_gen_socket;   // initiator socket in order to get data from powergenerator
	tlm_utils::simple_initiator_socket<EnergyBox>* cpu_appliance_socket[M_APPLIANCE]; //vector of initiator socket to get data from all appliances
	tlm_utils::simple_initiator_socket<EnergyBox>* cpu_battery_socket[N_BATTERY]; //vector of initiator socket to get data from all batteries
    
	//initialize the battery and appliance map, the sockets and the utility vector
	SC_CTOR(EnergyBox) : pow_gen_socket("pow_gen_socket")     
	{

		for (unsigned int i = 0; i < N_BATTERY; i++) {
			char txt[20];
			sprintf(txt, "cpu_battery_socket_%d", i);
			cpu_battery_socket[i]= new tlm_utils::simple_initiator_socket<EnergyBox>(txt);
		}
		
		for (unsigned int j = 0; j < M_APPLIANCE; j++) {
			char txt[20];
			sprintf(txt, "cpu_appliance_socket_%d", j);
			cpu_appliance_socket[j]= new tlm_utils::simple_initiator_socket<EnergyBox>(txt); //index distinti
		}

		data = 0;
		cost_f23=0;
		cost_f1=0;
		fulfill=true;
		cpu_W_cmd = static_cast<tlm::tlm_command>(tlm::TLM_WRITE_COMMAND);
		cpu_R_cmd = static_cast<tlm::tlm_command>(tlm::TLM_READ_COMMAND);
		pow_gen_cmd = static_cast<tlm::tlm_command>(tlm::TLM_READ_COMMAND);
		SC_THREAD(thread_process);

	}

private:

	std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
	    std::stringstream ss(s);
	    std::string item;
	    while (std::getline(ss, item, delim)) {
		elems.push_back(item);
	    }
	    return elems;
	}


	std::vector<std::string> split(const std::string &s, char delim) {
	    std::vector<std::string> elems;
	    split(s, delim, elems);
	    return elems;
	}

	//get max from a vector and his index
	int getMax(int a[], int dim) {
		int* max = new int[2];
		max[0] = 0;
		for (int i = 0; i < dim; i++) {
			if (max[0] < a[i]) {
				max[0] = a[i];
				max[1] = i;
			}
		}
		return max[1];
	}
	//get max from a vector not considering for element j
	int* getMaxExclusive(int a[], int dim, int j) {
		int* max = new int[2];
		max[0] = 0;
		for (int i = 0; i < dim; i++) {
			if (i == j)
				continue;
			if (max[0] < a[i]) {
				max[0] = a[i];
				max[1] = i;
			}
		}
		return max;
	}
	//extract the maximum from a vector excluding all indexes in vector j
	inline int getMaxExclusiveVector(int a[], int dim, int j[]) {
		int* max = new int[2];
		int * c = new int[dim];
		int* d = new int[dim];
		for (int k = 0; k < dim; k++) {
			c[k] = a[k];
			d[k] = j[k];
		}
		max[0] = 0;
		for (int k = 0; k < dim; k++) {
			for (int i = 0; i < dim; i++) {
				if (d[i] != -1)
					c[d[i]] = 0;
			}
			if (max[0] < c[k]) {
				max[0] = c[k];
				max[1] = k;
			}

		}
		return max[1];
	}
	//resume values of the utility vector
	inline void resumeValues(int b[], int dim) {
		for (int i = 0; i < dim; i++) {
			b[i] = -1;
		}
	}


	void thread_process() {
		tlm::tlm_generic_payload* cpu_appliance_trans =	new tlm::tlm_generic_payload[M_APPLIANCE];
		tlm::tlm_generic_payload* cpu_battery_trans =new tlm::tlm_generic_payload[N_BATTERY];
		tlm::tlm_generic_payload* pow_gen_trans = new tlm::tlm_generic_payload;
		sc_time delay = sc_time(1, SC_NS);
		int b_level;  //contains the battery level
		int b_state;  //contains the battery state (charging/not recharging)
		int a_status; //contains the appliance status(battery/powergenerator)
		int a_level;  //contains the appliance request
		int appliance_status[M_APPLIANCE];  //vector storing appliance status
		int appliance_level[M_APPLIANCE];  //vector storing appliance level
		int battery_level[N_BATTERY];   //vector storing battery level
		int battery_state[N_BATTERY]; //vector storing battery state



		// STARTING SIMULATION
		for (int i = START; i < END; i++) {

			// GETTING POWER GENERATOR CURRENT DRAIN TOTAL
			// ==============================================================================================================================

			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(1);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_current_total));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

	//		cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: CURRENT_DRAIN_TOTAL :: {"<< pow_gen_current_total << "}\n";


			// GETTING POWER GENERATOR CURRENT DRAIN GRID
			// ==============================================================================================================================

			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(0);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_current_grid));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			int index = sc_time_stamp().value() / 1000;
			pow_gen_current[index];
			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

			//cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: CURRENT_DRAIN_GRID :: {"<< pow_gen_current_grid << "}\n";

/*
			// GETTING POWER GENERATOR CURRENT DRAIN SOLAR
			// ==============================================================================================================================

			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(2);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_current_solar));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

		//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: CURRENT_DRAIN_SOLAR :: {"<< pow_gen_current_solar << "}\n";

			// GETTING POWER GENERATOR MAX CURRENT SOLAR
			// ==============================================================================================================================

			pow_gen_trans->set_command(pow_gen_cmd);
			pow_gen_trans->set_address(3);
			pow_gen_trans->set_data_ptr(
					reinterpret_cast<unsigned char*>(&pow_gen_max_current_solar));
			pow_gen_trans->set_data_length(4);
			pow_gen_trans->set_streaming_width(4); // = data_length to indicate no streaming
			pow_gen_trans->set_byte_enable_ptr(0); // 0 indicates unused
			pow_gen_trans->set_dmi_allowed(false); // Mandatory initial value
			pow_gen_trans->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value
			pow_gen_socket->b_transport(*pow_gen_trans, delay); // Blocking transport call

			// Initiator obliged to check response status and delay
			if (pow_gen_trans->is_response_error())
				SC_REPORT_ERROR("TLM-2",
						"Powergenerator_transaction - Response error from b_transport");

		//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "PowerGenerator" << " :: MAX_CURRENT_SOLAR :: {"<< pow_gen_current_solar << "}\n";

		*/	

			// GET Battery Level from CPU_BATTERY
			// ==============================================================================================================================
			// address = 1 => get battery level
			for (int k = 0; k < N_BATTERY; k++) {
				cpu_battery_trans[k].set_command(cpu_R_cmd);
				cpu_battery_trans[k].set_address(1);
				cpu_battery_trans[k].set_data_ptr(
						reinterpret_cast<unsigned char*>(&b_level));
				cpu_battery_trans[k].set_data_length(4);
				cpu_battery_trans[k].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_battery_trans[k].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_battery_trans[k].set_dmi_allowed(false); // Mandatory initial value
				cpu_battery_trans[k].set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_battery_socket[k])->b_transport(cpu_battery_trans[k], delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_battery_trans[k].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

			//	cout <<  "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Battery [" << k << "] Level =" << " :: " << b_level<< "\n";

				battery_level[k] = b_level;
			}

			// GET Battery State (Recharging/Not recharging) CPU_BATTERY_socket
			// ==============================================================================================================================
			// 0 = get battery state
			for (int k = 0; k < N_BATTERY; k++) {
				cpu_battery_trans[k].set_command(cpu_R_cmd);
				cpu_battery_trans[k].set_address(0);
				cpu_battery_trans[k].set_data_ptr(
						reinterpret_cast<unsigned char*>(&b_state));
				cpu_battery_trans[k].set_data_length(4);
				cpu_battery_trans[k].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_battery_trans[k].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_battery_trans[k].set_dmi_allowed(false); // Mandatory initial value
				cpu_battery_trans[k].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_battery_socket[k])->b_transport(cpu_battery_trans[k], delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_battery_trans[k].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

			//	cout << "$EASIM> "  << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Battery [" << k << "] State =" << " :: " << b_state<< "\n";

				battery_state[k] = b_state;
			}

			

			// 6 - GET APPLIANCE STATUS FROM CPU_APPLIANCE
			// STATUS 1 = usando batteria , STATUS 0  = usando pow_gen
			// ==========================================
			for (int j = 0; j < M_APPLIANCE; j++) {
				cpu_appliance_trans[j].set_command(cpu_R_cmd);
				cpu_appliance_trans[j].set_address(0);
				cpu_appliance_trans[j].set_data_ptr(
						reinterpret_cast<unsigned char*>(&a_status));
				cpu_appliance_trans[j].set_data_length(4);
				cpu_appliance_trans[j].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_appliance_trans[j].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_appliance_trans[j].set_dmi_allowed(false); // Mandatory initial value
				cpu_appliance_trans[j].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_appliance_socket[j])->b_transport(cpu_appliance_trans[j],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_appliance_trans[j].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

		//		cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Appliance [" << j << "] Status = " << ":: "<< a_status << "\n";

				appliance_status[j] = a_status;
			}

			// 7 - GET APPLIANCE LEVEL FROM CPU_APPLIANCE
			// ==========================================
			for (int j = 0; j < M_APPLIANCE; j++) {
				cpu_appliance_trans[j].set_command(cpu_R_cmd);
				cpu_appliance_trans[j].set_address(1);
				cpu_appliance_trans[j].set_data_ptr(
						reinterpret_cast<unsigned char*>(&a_level));
				cpu_appliance_trans[j].set_data_length(4);
				cpu_appliance_trans[j].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_appliance_trans[j].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_appliance_trans[j].set_dmi_allowed(false); // Mandatory initial value
				cpu_appliance_trans[j].set_response_status(
						tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_appliance_socket[j])->b_transport(cpu_appliance_trans[j],
						delay); // Blocking transport call ,anche con il vettore

				// Initiator obliged to check response status and delay
				if (cpu_appliance_trans[j].is_response_error())
					SC_REPORT_ERROR("TLM-2",
							"Battery_transaction - Response error from b_transport");

			//	cout << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "Appliance[" << j << "] Level = " << ":: " << a_level<< "\n";

				appliance_level[j] = a_level;

			}


			// APPLYING APPLIANCES ACTIONS
			// ==============================================================================================================================
/*

			for (int i_app = 0; i_app < M_APPLIANCE; i_app++) {
		
				int the_addr = 32;
				data = CPU_APPLIANCE_DATA[i][i_app];
				cpu_appliance_trans[i_app].set_command(cpu_W_cmd);
				cpu_appliance_trans[i_app].set_address(the_addr);
				cpu_appliance_trans[i_app].set_data_ptr(reinterpret_cast<unsigned char*>(&data));
				cpu_appliance_trans[i_app].set_data_length(4);
				cpu_appliance_trans[i_app].set_streaming_width(4); // = data_length to indicate no streaming
				cpu_appliance_trans[i_app].set_byte_enable_ptr(0); // 0 indicates unused
				cpu_appliance_trans[i_app].set_dmi_allowed(false); // Mandatory initial value
				cpu_appliance_trans[i_app].set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); // Mandatory initial value

				(*cpu_appliance_socket[i_app])->b_transport((cpu_appliance_trans)[i_app], delay); // Blocking transport call

				// Initiator obliged to check response status and delay
				if (cpu_appliance_trans[i_app].is_response_error())
					SC_REPORT_ERROR("TLM-2","Response error from b_transport - APPLIANCE SOCKET");

			//	cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "NEW_APPLIANCE_SETTING : "<< "Appliance[" << i_app << "] :: {" << data << "}\n";


			}
		*/	
			

			// APPLYING BATTERIES ACTIONS
			// ==============================================================================================================================

          if(pow_gen_current_grid > THRESHOLD && b_level >80){
			for (int i_batt = 0; i_batt < N_BATTERY; i_batt++) {	
				//data = CPU_BATTERY_DATA[i][i_batt]; 
					data = 2;								//data =2 force to discharge the battery (this data will be forwarded to the battery throught its CPU)
					cpu_battery_trans[i_batt].set_command(cpu_W_cmd);
					cpu_battery_trans[i_batt].set_address(1);			 //address 1 = battery discharge (indication for the CPU_Battery)
					cpu_battery_trans[i_batt].set_data_ptr(reinterpret_cast<unsigned char*>(&data));
					cpu_battery_trans[i_batt].set_data_length(4);
					cpu_battery_trans[i_batt].set_streaming_width(4); 
					cpu_battery_trans[i_batt].set_byte_enable_ptr(0); 
					cpu_battery_trans[i_batt].set_dmi_allowed(false); 
					cpu_battery_trans[i_batt].set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); 
					(*cpu_battery_socket[i_batt])->b_transport((cpu_battery_trans)[i_batt], delay); 

					// Initiator obliged to check response status and delay
					if (cpu_battery_trans[i_batt].is_response_error())
						SC_REPORT_ERROR("TLM-2","Response error from b_transport - BATTERY SOCKET");

			//	    	cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "NEW_BATTERY_SETTING : "<< "Battery[" << i_batt << "] :: {" << data << "}\n";

				} 
			}
			
            if(b_level <10 ){
            	for (int i_batt = 0; i_batt < N_BATTERY; i_batt++) {	
					//data = CPU_BATTERY_DATA[i][i_batt]; 
					data = 1;									//data =1 force to charge the battery (this data will be forwarded to the battery throught its CPU)
					cpu_battery_trans[i_batt].set_command(cpu_W_cmd);
					cpu_battery_trans[i_batt].set_address(0);         //address 0 = battery charge (indication for the CPU_Battery)
					cpu_battery_trans[i_batt].set_data_ptr(reinterpret_cast<unsigned char*>(&data));
					cpu_battery_trans[i_batt].set_data_length(4);
					cpu_battery_trans[i_batt].set_streaming_width(4); 
					cpu_battery_trans[i_batt].set_byte_enable_ptr(0); 
					cpu_battery_trans[i_batt].set_dmi_allowed(false); 
					cpu_battery_trans[i_batt].set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); 
					(*cpu_battery_socket[i_batt])->b_transport((cpu_battery_trans)[i_batt], delay); 

					// Initiator obliged to check response status and delay
					if (cpu_battery_trans[i_batt].is_response_error())
						SC_REPORT_ERROR("TLM-2","Response error from b_transport - BATTERY SOCKET");

			//	    	cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "NEW_BATTERY_SETTING : "<< "Battery[" << i_batt << "] :: {" << data << "}\n";

			    } 

			}


			// CALCULATE INSTANT COST
			// ==============================================================================================================================

			if ( i >= 28800 &&  i < 68400 ) {
				cost_f1 +=  pow_gen_current_grid;
				

			}else if ( i < 28800 ||  i >= 68400 ) {
				cost_f23 += pow_gen_current_grid;

			}


			// CHECKING AGGREGATOR REQUEST FULFILMENT AND DECLARE TOTAL COSTS
			// ==============================================================================================================================
			if(pow_gen_current_grid > THRESHOLD){ //aggregator request is usally given in kW
				fulfill = false;
			}
			if((sc_time_stamp().value() / 1000)+START == END-1){
				
				if(fulfill){
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "WARNING :: REQUEST FULFILLMENT ACHIEVED" << " \n";
				}else if (!fulfill && (sc_time_stamp().value() / 1000)+START == END-1){
				cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox"<< " :: " << "WARNING :: REQUEST NOT FULFILLED" <<  "\n";
				}

			cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "CONSUMPTION ON F1 PERIOD" << " :: {" <<  cost_f1 << "}"<< "\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "CONSUMPTION ON F23 PERIOD" << " :: {" << cost_f23 << "}"<< "\n";
			cost_f1  =  ( (cost_f1 / 1000) * c_factor) * F1;
			cost_f23 =  ( (cost_f23 / 1000) * c_factor) * F23;
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "COST FOR F1 PERIOD" << " :: {" << cost_f1 << "}"<< "\n";
			cout << "$EASIM> " << sc_time_stamp() << " :: " << "EnergyBox" << " :: "<< "COST FOR F23 PERIOD" << " :: {" << cost_f23 << "}"<< "\n";
			}

			wait(delay);

		} //CLOSE OUTER FOR
		// ========================================================================================================================================================================

	} //CLOSE THREAD

};
