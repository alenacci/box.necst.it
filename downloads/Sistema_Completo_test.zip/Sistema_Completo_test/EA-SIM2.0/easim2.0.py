import shlex                #File: easim2.0.py 
import subprocess           #Author: Giovanni Bettinazzi 
import os                   #email: g.bettinazzi@gmail.com
import sys
import shutil
import glob
import datetime
import smtplib
import re
import os
import json   
import time

#Utility function to elaborate time from hh:mm format to seconds
def elaborate_time(string):
    time = string.split(":")                            
    time_final = (int(time[0])*60 + int(time[1]))*60  
    return time_final



# -----------------INPUT LENGTH CONTROL ---------------------
if len(sys.argv) <= 1:
  print "EA-SIM 2.0 >> Error: Missing parameters starting time (hh:mm), ending time (hh:mm), reduction amount (kW) ['-s' for silent mode]"
  sys.exit(-1)
elif len(sys.argv) <=2:
    print "EA-SIM 2.0 >> Error: Missing parameters ending time (hh:mm), reduction amount (kW) ['-s' for silent mode]"
    sys.exit(-1)
elif len(sys.argv) <=3:
    print "EA-SIM 2.0 >> Error: Missing parameter reduction amount (kW) ['-s' for silent mode]"
    sys.exit(-1)

# -----------------INPUT FORMAT CONTROL ---------------------

if not ":" in sys.argv[1]:
    print "EA-SIM 2.0 >> Error: starting time need to be in hh:mm format"
    sys.exit(-1)

if not ":" in sys.argv[2]:
    print "EA-SIM 2.0 >> Error: ending time need to be in hh:mm format"
    sys.exit(-1)

# -----------------GETTING INPUT PARAMETERS ---------------------

silent =0
starting = elaborate_time(sys.argv[1])
ending = elaborate_time(sys.argv[2])
amount = int(float(sys.argv[3])*1000)


if starting > ending:
    print "EA-SIM 2.0 >> Error: Starting time greater than ending time"
    sys.exit(-1)

# if(len(sys.argv)>4 and "-s" in sys.argv[4]):
#   silent = 1
#   print "EA-SIM 2.0 >>  WARNING: Running in silent mode ! only system information will be generated"
# else:
#   print "EA-SIM 2.0 >>  WARNING: Silent mode not selected ! all information will be generated"

# -----------------GETTING NUMBER OF COMPONENTS  ---------------------

with open("network_description.json",'r') as json_file:
      data = json.load(json_file) 
      json_file.close()

appl =len(data['network'][0]['appliances'])  #extract the number of appliances defined
batt =len(data['network'][0]['batteries'])  #extract the number of batteries defined

# -----------------RUN THE SIMULATION  ---------------------
s_time = time.time()

#print "EA-SIM 2.0 >>  Selected simulation time interval "+str(starting)+" - "+str(ending)+" s"
#print "EA-SIM 2.0 >>  Selected DR aggregator request "+sys.argv[3]+" kW rounded to "+str(amount)+" W"


#print 'EA-SIM 2.0 >>  Creating appliances based on network description and gannt json file'
if(silent ==0):
  os.system('python create_appliances.py ')
else:
  os.system('python create_appliances.py '+str(silent))

#print 'EA-SIM 2.0 >>  Creating top.cpp file'
os.system('python top_generator.py'+" "+str(starting)+" "+str(ending)+" "+str(amount))

print 'EA-SIM 2.0 >>  Running simulation ('+str(ending-starting)+" iterations)"
os.environ["LD_LIBRARY_PATH"] = "/usr/local/systemc-2.3/lib-linux64:$LD_LIBRARY_PATH"
os.system('g++ -I. -I$SYSTEMC_HOME/include -L. -L$SYSTEMC_HOME/lib-linux64 -o out top.cpp -lsystemc -lm')

#print 'EA-SIM 2.0 >>  Creating dump.txt file'
os.system('./out > dump.txt')

print 'EA-SIM 2.0 >>  Creating power curves and data files'
if(silent ==0):
  os.system('python get_data_curves.py '+str(appl)+" "+str(batt)+" "+str(amount))
else:
  os.system('python get_data_curves.py '+str(appl)+" "+str(batt)+" "+str(amount)+" "+str(silent))

total_time = (time.time() - s_time)
total_time = round(total_time,3)
print 'EA-SIM 2.0 >> END OF SIMULATION (simulation time interval [h]= '+str(sys.argv[1])+'h : '+str(sys.argv[2]+'h reduction required = '+str(amount)+' W )')
#print 'EA-SIM 2.0 >> SIMULATION LASTS '+str(total_time)+" seconds"