import json           #File: top_generator.py 
import shlex          #Author: Giovanni Bettinazzi                                       
import subprocess     #email: g.bettinazzi@gmail.com
import os
import sys
import shutil
import glob
import datetime
import smtplib
import re
from pprint import pprint

#-------------------------------------------------------------------------------Utility and GET functions ------------------------------------------------------------------------------------------------


#write defines and includes in the .cpp file
def write_preambolo(appl,names):
    out_file.write("#define SC_INCLUDE_DYNAMIC_PROCESSES")
    out_file.write("\n")
    out_file.write("#include \"systemc\"")
    out_file.write("\n")
    out_file.write("using namespace sc_core;"+"\n"+"using namespace sc_dt;"+"\n"+"using namespace std;"+"\n")
    out_file.write("#include \"tlm.h\"")
    out_file.write("\n")
    out_file.write("#include \"tlm_utils/simple_initiator_socket.h\"")
    out_file.write("\n")
    out_file.write("#include \"tlm_utils/simple_target_socket.h\"")
    out_file.write("\n")
    out_file.write("#include \"iostream\"")
    out_file.write("\n")
    out_file.write("#include \"Archive/Appliance/CPU_Appliance.h\"")
    out_file.write("\n")
    for i in range(0,appl):
      # if class_name[i] == names[i]:
      out_file.write("#include \"Archive/Appliance/Appliance"+str(names[i])+".h\"")
      out_file.write("\n")
    out_file.write("#include \"Archive/Battery/BatteryFlexi.h\"")
    out_file.write("\n")
    out_file.write("#include \"Archive/Battery/CPU_Battery.h\"")
    out_file.write("\n")
    out_file.write("#include \"Archive/EnergyBox/EnergyBox.h\"")
    out_file.write("\n")
    out_file.write("#include \"Archive/PowerGenerator/PowerGenerator.h\"")
    out_file.write("\n")
    out_file.write("\n")
    out_file.write("\n")

#Function that write the number of components in the .cpp file
def write_numbers_of_components(appl):
        napp= "#define N_APP"+" "+(str(appl))
        #nbatt= "#define N_BATT"+" "+(str(batt))
        nbatt = "#define N_BATT"+" 1"
        out_file.write(napp)
        out_file.write("\n")
        out_file.write(nbatt)
        out_file.write("\n")
        out_file.write("\n")
        out_file.write("\n")

#----------------------------------------------------------------Functions to declare the components in constructor----------------------------------------------------------------

def write_appliance_in_constructor(index,start,end,name):
        out_file.write("\t\t"+str(name)+"= new Appliance"+str(name)+"<"+str(index)+","+str(start)+","+str(end)+">(\""+str(name)+"\");")
        out_file.write("\n")
        
def write_batteries_in_constructor(index,start,end):
        out_file.write("\t\ti_Battery"+str(index)+"= new BatteryFlexi<"+str(index)+","+str(start)+","+str(end)+">(\"i_Battery"+str(index)+"\");")
        out_file.write("\n")
        
def write_ebox_in_constructor(index,start,end,amount):
        out_file.write("\t\ti_EnergyBox= new EnergyBox<N_BATT,N_APP"+","+str(start)+","+str(end)+","+str(amount)+">(\"i_EnergyBox\");")
        out_file.write("\n")
                
def write_pgen_in_constructor(index,start,end):
        out_file.write("\t\ti_PowerGenerator= new PowerGenerator<N_APP,N_BATT"+","+str(start)+","+str(end)+">(\"i_PowerGenerator\");")
        out_file.write("\n")

def write_cpuAppliance_in_constructor(index):  
        out_file.write("\t\ti_CPU_Appliance"+str(index)+"= new CPU_Appliance<"+str(index)+">(\"i_CPU_Appliance"+str(index)+"\");")
        out_file.write("\n")

def write_cpuBatteries_in_constructor(index,start,end):
        out_file.write("\t\ti_CPU_Battery"+str(index)+"= new CPU_Battery<"+str(index)+","+str(start)+","+str(end)+">(\"i_CPU_Battery"+str(index)+"\");")
        out_file.write("\n")

#----------------------------------------------------------------Functions to write connections----------------------------------------------------------------

def write_appliance_connection_CPU(index,name):  
        out_file.write("\t\t"+str(name)+"->socket.bind(i_CPU_Appliance"+str(index)+"->appliance_socket);")
        out_file.write("\n")

def write_ebox_connection_cpu(index):
        out_file.write("\t\ti_EnergyBox->cpu_appliance_socket["+str(index)+"]->bind(i_CPU_Appliance"+str(index)+"->energy_box_socket);")
        out_file.write("\n")       

def write_ebox_connection_pgen(index):
        out_file.write("\t\ti_EnergyBox->pow_gen_socket.bind(i_PowerGenerator->energy_box_socket);")

def write_ebox_connection_batteries(index):
        out_file.write("\t\ti_EnergyBox->cpu_battery_socket["+str(index)+"]->bind(i_CPU_Battery"+str(index)+"->energy_box_socket);")	
        out_file.write("\n")

def write_cpu_connection_pgen(index):
       out_file.write("\t\ti_CPU_Appliance"+str(index)+"->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket["+str(index)+"]);")
       out_file.write("\n")

def write_cpubatt_batteries(index):
      out_file.write("\t\ti_CPU_Battery"+str(index)+"->battery_socket.bind (i_Battery"+str(index)+"->cpu_socket);")
      out_file.write("\n")

def write_battery_pgen(index,appl):
      out_file.write("\t\ti_Battery"+str(index)+"->recharge_socket.bind( *i_PowerGenerator->en_req_socket["+str(appl+index)+"]);")
      out_file.write("\n")
      out_file.write("\t\ti_Battery"+str(index)+"->discharge_socket.bind( *i_PowerGenerator->en_req_socket["+str(appl+index+1)+"]);")
      out_file.write("\n")

#----------------------------------------------------------------Functions to declare the components ----------------------------------------------------------------
      
def declare_appliances(index,start,end,name):
        out_file.write("\tAppliance"+str(name)+"<"+str(index)+","+str(start)+","+str(end)+">"+" *"+str(name)+";")
        out_file.write("\n")
        
def declare_batteries(index,start,end):
        out_file.write("\tBatteryFlexi<"+str(index)+","+str(start)+","+str(end)+">"+"  "+"*i_Battery"+str(index)+";")
        out_file.write("\n")

def declare_powergenerators(index,start,end): #normally there is just one powergenerator but I keep the index for further implementation
        out_file.write("\tPowerGenerator<N_APP,N_BATT"+","+str(start)+","+str(end)+">"+"  "+"*i_PowerGenerator;")
        out_file.write("\n")

def declare_cpubatteries(index,start,end):
        out_file.write("\tCPU_Battery<"+str(index)+","+str(start)+","+str(end)+">"+"  "+"*i_CPU_Battery"+str(index)+";")
        out_file.write("\n")
        
def declare_cpuappliances(index): 
        out_file.write("\tCPU_Appliance<"+str(index)+">"+"  "+"*i_CPU_Appliance"+str(index)+";")
        out_file.write("\n")
        
def declare_energybox(index,start,end,amount):
        out_file.write("\tEnergyBox<N_BATT,N_APP"+","+str(start)+","+str(end)+","+str(amount)+">"+"  "+"*i_EnergyBox;")
        out_file.write("\n")
#----------------------------------------------------------------Functions to write the main() and the constructor----------------------------------------------------------------

def write_main():
       out_file.write("int sc_main(int argc, char* argv[])"+"\n"+"{"+"\n"+"\tTop"+" "+"top(\"top\");"+"\n"+"\tsc_start();"+"\n"+"\treturn 0;"+"\n"+"}")

def start_declare():
     out_file.write("SC_MODULE(Top)"+"\n"+"{"+"\n")

def start_constructor():
    out_file.write("\tSC_CTOR(Top)"+"\n"+"\t{"+"\n")
       
def end_constructor():
    out_file.write("\t}")
    out_file.write("\n")
    out_file.write("};")
    out_file.write("\n")
    out_file.write("\n")

#---------------------------------------------------------------end of defined functions section------------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


#--------------------------------------------------------------------Program main ------------------------------------------------------------------------------------------------

if len(sys.argv) <= 1:
  print "Error: Missing parameter starting time (hh:mm), ending time (hh:mm) and reduction amount (W) "
  sys.exit(-1)
elif len(sys.argv) <=2:
    print "Error: Missing parameter ending time (hh:mm) and reduction amount (W)"
    sys.exit(-1)
elif len(sys.argv) <=3:
    print "Error: Missing parameter reduction amount (W)"
    sys.exit(-1)

start =sys.argv[1]
end = sys.argv[2]
amount = int((sys.argv[3])) #threshold already converted in W from easim2.0.py




out_file= open("top.cpp","w")

#network_description.json contains appliances attributes
with open("network_description.json",'r') as json_file:
      data = json.load(json_file) 
      json_file.close()

appl =len(data['network'][0]['appliances'])  #extract the number of appliances defined
batt =len(data['network'][0]['batteries'])  #extract the number of batteries defined
gen =len(data['network'][0]['generators'])  #extract the number of power generators defined
ebox =str(data['network'][0]['groupId']).count("group_")  #extract the number of energyboxes defined
names=[None]*appl

for i in range(0,appl):
    names[i] = str(data['network'][0]['appliances'][i]['Name'])


write_preambolo(appl,names)			   #write imports and defines

write_numbers_of_components(appl)            #write number of components 

start_declare()    			          #begin of SC_MODULE


#-----------------------------------------------------------component declaration ------------------------------------------------------------------------------------------------
for i in range(0,appl):
    declare_appliances(i,start,end,names[i])
out_file.write("\n")            

for i in range(0,appl):  
    declare_cpuappliances(i)  
out_file.write("\n")

for i in range(0,batt):
   declare_batteries(i,start,end)
out_file.write("\n")
    
for i in range(0,batt):
    declare_cpubatteries(i,start,end)
out_file.write("\n")    

for i in range(0,gen):
    declare_powergenerators(i,start,end)
out_file.write("\n")

for i in range(0,ebox):
    declare_energybox(i,start,end,amount)
out_file.write("\n")
   
#-----------------------------------------------------------  Constructor ------------------------------------------------------------------------------------------------

#begin of constructor
out_file.write("\n")
start_constructor()
   #begin of SC_CTOR

#----------------------------------------------------------Write components in constructor --------------------------------------------------------------------------------

for i in range(0,appl):
    write_appliance_in_constructor(i,start,end,names[i])
out_file.write("\n")
    
for i in range(0,batt):
    write_batteries_in_constructor(i,start,end)
out_file.write("\n")      

for i in range(0,ebox):
    write_ebox_in_constructor(i,start,end,amount)
out_file.write("\n")        

for i in range(0,gen):
    write_pgen_in_constructor(i,start,end)
out_file.write("\n")        

for i in range(0,batt):
    write_cpuBatteries_in_constructor(i,start,end)
out_file.write("\n")    

for i in range(0,appl):
    write_cpuAppliance_in_constructor(i)
out_file.write("\n")

#-----------------------------------------------------------  Write component connections ---------------------------------------------------------------------------------------------

for i in range(0,appl):
    write_appliance_connection_CPU(i,names[i])
out_file.write("\t\tcout << \"Appliances-CPU_Appliance connections completed.\\n\";") 
out_file.write("\n")
out_file.write("\n")

for i in range(0,appl):
    write_ebox_connection_cpu(i)
    if(i== appl-1):
       out_file.write("\t\tcout << \"EnergyBox-CPU_Appliance connections completed.\\n \";") 
       out_file.write("\n")
       out_file.write("\n")
       write_ebox_connection_pgen(i)
       out_file.write("\n")
       out_file.write("\t\tcout << \"EnergyBox-PowerGenerator connections completed.\\n \";") 
       out_file.write("\n")
       out_file.write("\n")

for i in range(0,batt):
    write_ebox_connection_batteries(i)
out_file.write("\t\tcout << \"EnergyBox-CPU_Battery connections completed.\\n \";")
out_file.write("\n")
out_file.write("\n")

for i in range(0,appl):
    write_cpu_connection_pgen(i)
out_file.write("\t\tcout << \"CPU_Appliance-PowerGenerator connections completed.\\n \";")
out_file.write("\n")
out_file.write("\n")


for i in range(0,batt):
    write_cpubatt_batteries(i)
out_file.write("\t\tcout << \"CPU_Battery-Battery connections completed.\\n \";")
out_file.write("\n")
out_file.write("\n")

for i in range(0,batt):
     write_battery_pgen(i,appl)
out_file.write("\t\tcout << \"Battery-PowerGenerator connections completed.\\n \";")
out_file.write("\n")
out_file.write("\n")

#-----------------------------------------------------------Closing constructor, .cpp file and writing the main---------------------------------------------------------------------


end_constructor()  #end of constructor
write_main()      #writing main
out_file.close()  #close file


