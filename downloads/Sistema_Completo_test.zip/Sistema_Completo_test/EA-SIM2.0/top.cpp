#define SC_INCLUDE_DYNAMIC_PROCESSES
#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;
#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"
#include "tlm_utils/simple_target_socket.h"
#include "iostream"
#include "Archive/Appliance/CPU_Appliance.h"
#include "Archive/Appliance/ApplianceWashingMachine.h"
#include "Archive/Appliance/ApplianceComputer.h"
#include "Archive/Appliance/ApplianceIllumination.h"
#include "Archive/Appliance/ApplianceRefrigerator.h"
#include "Archive/Appliance/ApplianceFreezer.h"
#include "Archive/Battery/BatteryFlexi.h"
#include "Archive/Battery/CPU_Battery.h"
#include "Archive/EnergyBox/EnergyBox.h"
#include "Archive/PowerGenerator/PowerGenerator.h"


#define N_APP 5
#define N_BATT 1


SC_MODULE(Top)
{
	ApplianceWashingMachine<0,28800,32400> *WashingMachine;
	ApplianceComputer<1,28800,32400> *Computer;
	ApplianceIllumination<2,28800,32400> *Illumination;
	ApplianceRefrigerator<3,28800,32400> *Refrigerator;
	ApplianceFreezer<4,28800,32400> *Freezer;

	CPU_Appliance<0>  *i_CPU_Appliance0;
	CPU_Appliance<1>  *i_CPU_Appliance1;
	CPU_Appliance<2>  *i_CPU_Appliance2;
	CPU_Appliance<3>  *i_CPU_Appliance3;
	CPU_Appliance<4>  *i_CPU_Appliance4;

	BatteryFlexi<0,28800,32400>  *i_Battery0;

	CPU_Battery<0,28800,32400>  *i_CPU_Battery0;

	PowerGenerator<N_APP,N_BATT,28800,32400>  *i_PowerGenerator;

	EnergyBox<N_BATT,N_APP,28800,32400,2500>  *i_EnergyBox;


	SC_CTOR(Top)
	{
		WashingMachine= new ApplianceWashingMachine<0,28800,32400>("WashingMachine");
		Computer= new ApplianceComputer<1,28800,32400>("Computer");
		Illumination= new ApplianceIllumination<2,28800,32400>("Illumination");
		Refrigerator= new ApplianceRefrigerator<3,28800,32400>("Refrigerator");
		Freezer= new ApplianceFreezer<4,28800,32400>("Freezer");

		i_Battery0= new BatteryFlexi<0,28800,32400>("i_Battery0");

		i_EnergyBox= new EnergyBox<N_BATT,N_APP,28800,32400,2500>("i_EnergyBox");

		i_PowerGenerator= new PowerGenerator<N_APP,N_BATT,28800,32400>("i_PowerGenerator");

		i_CPU_Battery0= new CPU_Battery<0,28800,32400>("i_CPU_Battery0");

		i_CPU_Appliance0= new CPU_Appliance<0>("i_CPU_Appliance0");
		i_CPU_Appliance1= new CPU_Appliance<1>("i_CPU_Appliance1");
		i_CPU_Appliance2= new CPU_Appliance<2>("i_CPU_Appliance2");
		i_CPU_Appliance3= new CPU_Appliance<3>("i_CPU_Appliance3");
		i_CPU_Appliance4= new CPU_Appliance<4>("i_CPU_Appliance4");

		WashingMachine->socket.bind(i_CPU_Appliance0->appliance_socket);
		Computer->socket.bind(i_CPU_Appliance1->appliance_socket);
		Illumination->socket.bind(i_CPU_Appliance2->appliance_socket);
		Refrigerator->socket.bind(i_CPU_Appliance3->appliance_socket);
		Freezer->socket.bind(i_CPU_Appliance4->appliance_socket);
		cout << "Appliances-CPU_Appliance connections completed.\n";

		i_EnergyBox->cpu_appliance_socket[0]->bind(i_CPU_Appliance0->energy_box_socket);
		i_EnergyBox->cpu_appliance_socket[1]->bind(i_CPU_Appliance1->energy_box_socket);
		i_EnergyBox->cpu_appliance_socket[2]->bind(i_CPU_Appliance2->energy_box_socket);
		i_EnergyBox->cpu_appliance_socket[3]->bind(i_CPU_Appliance3->energy_box_socket);
		i_EnergyBox->cpu_appliance_socket[4]->bind(i_CPU_Appliance4->energy_box_socket);
		cout << "EnergyBox-CPU_Appliance connections completed.\n ";

		i_EnergyBox->pow_gen_socket.bind(i_PowerGenerator->energy_box_socket);
		cout << "EnergyBox-PowerGenerator connections completed.\n ";

		i_EnergyBox->cpu_battery_socket[0]->bind(i_CPU_Battery0->energy_box_socket);
		cout << "EnergyBox-CPU_Battery connections completed.\n ";

		i_CPU_Appliance0->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket[0]);
		i_CPU_Appliance1->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket[1]);
		i_CPU_Appliance2->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket[2]);
		i_CPU_Appliance3->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket[3]);
		i_CPU_Appliance4->powergenerator_socket.bind(*i_PowerGenerator->en_req_socket[4]);
		cout << "CPU_Appliance-PowerGenerator connections completed.\n ";

		i_CPU_Battery0->battery_socket.bind (i_Battery0->cpu_socket);
		cout << "CPU_Battery-Battery connections completed.\n ";

		i_Battery0->recharge_socket.bind( *i_PowerGenerator->en_req_socket[5]);
		i_Battery0->discharge_socket.bind( *i_PowerGenerator->en_req_socket[6]);
		cout << "Battery-PowerGenerator connections completed.\n ";

	}
};

int sc_main(int argc, char* argv[])
{
	Top top("top");
	sc_start();
	return 0;
}