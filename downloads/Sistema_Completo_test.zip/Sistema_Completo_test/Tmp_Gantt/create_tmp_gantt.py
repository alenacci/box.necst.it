import json                 #File: create_tmp_gantt.py     
import shlex                #Author: Giovanni Bettinazzi                 
import subprocess           #email: g.bettinazzi@gmail.com
import os                 
import sys 
import shutil
import glob
import datetime
import smtplib
import re
from pprint import pprint
import itertools
import MySQLdb

# -----------------DB CLASS ---------------------
class Database:
  def __init__(self, host='127.0.0.1', user='root', pwd='csabamonory', db='EA-SIMDB'):  #portatile host =127.0.0.1, fisso = localhost , gozzo = 10.79.3.212 pwd = easimpassword
    self.host = host
    self.user = user
    self.pwd = pwd
    self.db = db
    self.cur = None

  def open(self):
    self.con = MySQLdb.connect(
    host = self.host,
    user = self.user,
    passwd = self.pwd,
    db = self.db
    )

    self.cur = self.con.cursor()

  def close(self):
    return self.con.close()
  
  def executeWriteQuery(self, query):
    self.cur.execute(query)
    self.con.commit()

  def executeFormatReadQuery(self, query,formato):
    self.cur.execute(query,formato)
    return self.cur.fetchall()

  def executeFormatWriteQuery(self, query,formato):
    self.cur.execute(query,formato)
    self.con.commit()
# -----------------END OF DB CLASS ---------------------


# -----------------UTILITY FUNCTIONS  ---------------------

#Elaborate the time to write in the new gantt adding the delay to the old one, if the delay =0 just return the original time
def elaborate_time_to_write(string,delay):
    if delay ==0:
      return string

    time = string.split(":")                            
    new_minutes=int(time[1])+int(delay)   #adding the delay
    if(new_minutes>=60):          #elaborate time format to hh:mm
    	if(new_minutes%60 <10): 
    		time_final=str(int(time[0])+1)+':0'+str(new_minutes%60)  
    	else:
    		time_final=str(int(time[0])+1)+':'+str(new_minutes%60)
    else:
    	time_final=str(time[0])+':'+str(new_minutes)
    return time_final

#Elaborate the time from hh:mm format to seconds format 		
def elaborate_time(string):
    time = string.split(":")                            
    time_final = (int(time[0])*60 + int(time[1]))*60  
    return time_final

#Write a Json file
def write_json(string,data):
  with open(string+".json",'w') as json_out_file:
        json.dump(data,json_out_file,indent = True,sort_keys=True)
        json_out_file.close()

#Read a Json file
def read_json(string):
  with open(string+".json",'r') as json_file:
      data = json.load(json_file) 
      json_file.close()
  return data

#Given an input gantt filename, genate all the possibile combinations, mantaining the appliances with id != flag with their original 'from' time and delaying the one with id=flag
def read_write_gantt(input_gantt,flag,k):
  for i in range(0,appl):
    if( (i != flag)):         #check in order to do not delay the appliance with id != flag
        continue
    data = read_json(input_gantt)
    for j in range(0,len(data['appliance_'+str(i)])):        #if elastic appliance has more than 1 from-to interval defined
      if ('TRUE' in data['appliance_'+str(i)][j]['elastic']):
        data = read_json(input_gantt)
        
        if (k == 0 or k ==-1) :
          new_from_time = elaborate_time_to_write(data['appliance_'+str(i)][j]['from'],0) #if we are reading the original gantt , no delay will be added to 'from' field
        if "100" in data['appliance_'+str(i)][j]['from']:
        	continue
        else:
          new_from_time = elaborate_time_to_write(data['appliance_'+str(i)][j]['from'],delay) #new_from_time = from_time + delay of the appliance with ID = flag

        to_time = (elaborate_time(data['appliance_'+str(i)][j]['to']))
        cnt=0
        while (elaborate_time(new_from_time) <= to_time ):                   #iterations go on until the from_time + delay = to, so until the end of the from-to interval of appliance with ID = flag
          gantt_name = "tmp_gantt_"+str(i)+"_"+str(j)+"_"+str(cnt)+"_"+str(flag)+"_c"+str(k)    #if we are reading delayed gantt instead of rewrite the previous gantt we create new ones
          data['appliance_'+str(i)][j]['from'] = new_from_time                              
          write_json(gantt_name,data)                                        #write the new gantt file with the new_from_time for appliance with ID = flag
          data=read_json(gantt_name)                                         #read the gantt file created and get the 'from' field to be delayed
          new_from_time = elaborate_time_to_write(data['appliance_'+str(i)][j]['from'],delay) #add 30 minutes delay to the 'from' field of elastic appliance with ID = flag
          cnt+=1
  return 


def read_write_original_gantt(input_gantt):
	data=read_json(input_gantt)
	for i in range(0,appl):
		for j in range(0,len(data['appliance_'+str(i)])):
			if (len(data['appliance_'+str(i)])) >1 and 'TRUE' in data['appliance_'+str(i)][j]['elastic']:
				for k in range(0,len(data['appliance_'+str(i)])):
					data=read_json(input_gantt)
					if k == j:
						continue
					else:
						data['appliance_'+str(i)][k]['from'] = "100:00"
						data['appliance_'+str(i)][k]['to'] = "100:00"
						gantt_name="tmp_original_gantt"+str(i)+"_"+str(k)
						write_json(gantt_name,data)
			else:
				gantt_name="tmp_original_gant"
				write_json(gantt_name,data)









# -----------------END OF UTILITY FUNCTIONS DECLARATION ---------------------    

# -----------------INPUT LENGTH CONTROL AND GET ---------------------

if len(sys.argv) == 1:
  print "EA-SIM 2.0 >> Error: Missing parameters delay"
  sys.exit(-1)

delay = sys.argv[1]

# ------------------------------MAIN----------------------------------


data = read_json("gantt")
data2 =read_json("network_description")

new_from_time=""
to_time =""
cnt = 0;
active_appl_elastic=0
appl = len(data2['network'][0]['appliances']) 	#len(data2['network'][0]['appliances']) = number of appliances defined
index=[-1]*appl                                #index is a vector of all -1, is a utility vector for create index_elastic (the vector that will contain the ID of elastic appl)


#Extract number of elastic appliances actives that day
for i in range(0,appl):
  if 'TRUE' in data['appliance_'+str(i)][0]['elastic'] and "100" not in data['appliance_'+str(i)][0]['from']:
    active_appl_elastic +=1
    index[i]=i
index_elastic=[0]*active_appl_elastic



#Built a vector with index of appliances elastic
l = 0
for i in range(0,appl):
  if index[i] != -1:
    index_elastic[l]=index[i]
    l+=1
      
# -----------------WRITE ALL THE POSSIBLE COMBINATIONS IN tmp DIRECTORY  ---------------------

os.system("rm -f ./last_gantts/tmp*.json")   #remove old gantt
os.system("rm -f tmp*.json")   #remove old gantt
read_write_original_gantt("gantt")
os.system("ls tmp*.json > ./list.txt")   #at every step list.txt contains the name of the gantt_file generated at the previous iteration
#Write the combinations only if there are appliance time shiftable that are active in the gantt, if there aren't , the only gantt to be write in the db is the original gantt
if active_appl_elastic:  
  f = open("./list.txt")
  lines = f.readlines()
  f.close()
  m=-1
  for line in lines:
  	line = line.replace(".json","")[:-1]
  	read_write_gantt(line,index_elastic[0],m)
  	m+=1
  os.system("ls tmp*.json > ./list.txt")   #at every step list.txt contains the name of the gantt_file generated at the previous iteration


  k =1;  #range start from one in order to avoid repeating the same combination (AB = BA )
  for i in range(1,active_appl_elastic):   #for each appliance elastic, read from list.txt the gantt_files generated before and write a new gantt with only that appliance delayed and the other as the tmp_gantt 
    f = open("./list.txt")
    lines = f.readlines()
    f.close()
    for line in lines:
      line= line.replace(".json","")[:-1]   #get the tmp_gantt name
      read_write_gantt(line,index_elastic[i],k)                  #write the new gantt with only the appliance with id = index_elastic[i] delayed 
      k+=1
   
    os.system("ls tmp*.json > ./newlist.txt")
    os.system("grep -F -x -v -f ./list.txt ./newlist.txt > ./list2.txt")  #make the difference between the new list and the old one and save it in list2.txt in order to avoid repeated combinations
    os.system("rm ./list.txt")
    os.system("rm ./newlist.txt")
    os.system("mv ./list2.txt ./list.txt")   #list will always contain the names of the gantt file generated in the previous iteration and to be read in the next one



# -----------------WRITE THE tmp_gantt IN THE DB  ---------------------

os.system("rm ./list.txt")
os.system("ls tmp*.json > ./list.txt")   #now list.txt contains the name of all the tmp_gantt file generated 


db=Database()
db.open()
db.executeWriteQuery('DELETE FROM `Gantt` WHERE 1')  #delete the Gantt table before write
db.executeWriteQuery('ALTER TABLE `Gantt` AUTO_INCREMENT =1') #reset the ID field value
f = open("./list.txt")
lines = f.readlines()
f.close()
for line in lines:
  name=line.replace(".json","")[:-1]   #the name of the gantt file
  content = str(read_json(name)).replace("u'","\"").replace("'","\"")   #the content of the gantt file
  formato = "(name,content)"     #the content of the %s place holders
  sqlW= "INSERT INTO `Gantt`(`Gantt_name`,`Gantt_content`) VALUES (%s,%s)"    #the write query body
  db.executeFormatWriteQuery(sqlW,(name,content))   #write the gantt in the db

db.close()
print "EA-SIM 2.0 >> Gantt combinations created and saved sucessfully in the Database"

os.system("mv tmp*.json ./last_gantts")   #move the last produced gantts to the last_gantts directory to keep the main directory clean